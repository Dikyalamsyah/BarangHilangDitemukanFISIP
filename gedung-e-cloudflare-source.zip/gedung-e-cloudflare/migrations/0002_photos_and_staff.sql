CREATE TABLE photos (
  key TEXT PRIMARY KEY NOT NULL,
  jpeg BLOB NOT NULL CHECK(typeof(jpeg)='blob' AND length(jpeg) BETWEEN 4 AND 380000)
);

CREATE TABLE photo_usage (
  id INTEGER PRIMARY KEY CHECK(id=1),
  bytes INTEGER NOT NULL DEFAULT 0
);
INSERT INTO photo_usage(id) VALUES (1);

-- Keep room in the 500 MB Free database for reports, claims and indexes.
CREATE TRIGGER photo_storage_limit BEFORE INSERT ON photos
WHEN (SELECT bytes FROM photo_usage WHERE id=1) + length(NEW.jpeg) > 420000000
BEGIN
  SELECT RAISE(ABORT, 'gedung_e_photo_limit');
END;

CREATE TRIGGER photo_storage_insert AFTER INSERT ON photos
BEGIN
  UPDATE photo_usage SET bytes=bytes+length(NEW.jpeg) WHERE id=1;
END;

CREATE TRIGGER photo_storage_delete AFTER DELETE ON photos
BEGIN
  UPDATE photo_usage SET bytes=bytes-length(OLD.jpeg) WHERE id=1;
END;

CREATE TABLE staff_account (
  id INTEGER PRIMARY KEY CHECK(id=1),
  password_digest TEXT NOT NULL,
  revision TEXT NOT NULL,
  activation_fingerprint TEXT NOT NULL
);

CREATE TABLE staff_sessions (
  token_hash TEXT PRIMARY KEY NOT NULL,
  account_revision TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX staff_sessions_by_expiry ON staff_sessions(expires_at);

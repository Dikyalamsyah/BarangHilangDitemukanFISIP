CREATE TABLE `claims` (
	`id` text PRIMARY KEY NOT NULL,
	`report_id` text NOT NULL,
	`request_key` text NOT NULL,
	`tracking_hash` text NOT NULL,
	`claimant_name` text NOT NULL,
	`proof` text NOT NULL,
	`state` text DEFAULT 'submitted' NOT NULL,
	`pickup` text,
	`photo_key` text,
	`photo_consent` integer DEFAULT 0 NOT NULL,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	`handed_over_at` integer,
	FOREIGN KEY (`report_id`) REFERENCES `reports`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "claim_state_valid" CHECK("claims"."state" IN ('submitted','ready','rejected','returned')),
	CONSTRAINT "handover_photo_requires_consent" CHECK("claims"."photo_key" IS NULL OR ("claims"."photo_consent"=1 AND "claims"."state"='returned'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `claims_request_key_unique` ON `claims` (`request_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `claims_tracking_hash_unique` ON `claims` (`tracking_hash`);--> statement-breakpoint
CREATE INDEX `claims_by_report_and_state` ON `claims` (`report_id`,`state`);--> statement-breakpoint
CREATE INDEX `claims_by_history` ON `claims` (`state`,`handed_over_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `one_owner_claim_per_report` ON `claims` (`report_id`) WHERE "claims"."state" IN ('ready','returned');--> statement-breakpoint
CREATE TABLE `reports` (
	`id` text PRIMARY KEY NOT NULL,
	`request_key` text NOT NULL,
	`kind` text NOT NULL,
	`title` text NOT NULL,
	`category` text NOT NULL,
	`location` text NOT NULL,
	`description` text NOT NULL,
	`reporter_name` text NOT NULL,
	`reporter_contact` text,
	`photo_key` text,
	`state` text DEFAULT 'pending' NOT NULL,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL,
	`published_at` integer,
	CONSTRAINT "report_kind_valid" CHECK("reports"."kind" IN ('found','lost')),
	CONSTRAINT "report_state_valid" CHECK("reports"."state" IN ('pending','published','archived'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `reports_request_key_unique` ON `reports` (`request_key`);--> statement-breakpoint
CREATE INDEX `reports_by_state` ON `reports` (`state`,`published_at`);--> statement-breakpoint
CREATE TABLE `request_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL,
	`count` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `request_limits_by_expiry` ON `request_limits` (`expires_at`);
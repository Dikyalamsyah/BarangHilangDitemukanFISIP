import { cp, mkdir, rm, writeFile } from 'node:fs/promises';
import { build } from 'esbuild';

const pages = process.argv.includes('--pages');

if (pages) {
  await rm('dist/pages', { recursive: true, force: true });
  await mkdir('dist/pages', { recursive: true });
  await cp('public', 'dist/pages', { recursive: true });
  const routes = { version: 1, include: ['/*'], exclude: ['/assets/*'] };
  await writeFile('dist/pages/_routes.json', JSON.stringify(routes));
}

await build({
  entryPoints: [pages ? 'worker/pages.ts' : 'worker/index.ts'],
  outfile: pages ? 'dist/pages/_worker.js' : 'dist/worker.mjs',
  platform: 'browser',
  target: 'es2022',
  bundle: true,
  format: 'esm',
  minify: true,
  legalComments: 'eof',
});

# Barang Hilang & Ditemukan Gedung E FISIP UI

Situs publik dan panel petugas berjalan di Cloudflare Pages. Laporan, klaim, sesi petugas, dan foto tersimpan di D1. Aset CSS, JavaScript, dan font disajikan sebagai aset statis Pages.

- Situs publik https://barang-hilang-dan-ditemukan.pages.dev/
- Panel petugas https://barang-hilang-dan-ditemukan.pages.dev/admin
- Aktivasi dan pemulihan akun https://barang-hilang-dan-ditemukan.pages.dev/admin/aktivasi

## Pengelolaan

Buka **Workers & Pages → barang-hilang-dan-ditemukan** di dashboard Cloudflare. Basis data **barang-hilang-gedung-e** tersedia di **Storage & databases → D1**. Simpan ekspor basis data di tempat dengan akses terbatas karena berisi data laporan dan klaim.

Untuk mengganti sandi saat sudah masuk, gunakan **Ubah sandi** di panel. Jika sandi terlupa, tambahkan Secret `GEDUNG_E_ADMIN_RECOVERY` di pengaturan produksi proyek Pages dengan kode acak baru minimal 24 karakter. Terbitkan ulang proyek, lalu masukkan kode di halaman aktivasi dan buat sandi baru. Kode pemulihan berlaku sekali pakai.

## Penerbitan ulang

Gunakan Node.js 22.18 atau lebih baru. Jalankan `npm ci`, `npm run check`, dan `npm run build:pages`. Build menghasilkan Worker dan aset siap unggah di `dist/pages`.

Masuk ke akun Cloudflare dengan `npx wrangler@4.92.0 login`. Kemudian jalankan:

```sh
npx wrangler@4.92.0 pages deploy dist/pages --project-name barang-hilang-dan-ditemukan --branch main --no-bundle
```

Di pengaturan produksi Pages, pertahankan binding `DB` ke basis data `barang-hilang-gedung-e`, pengaturan kompatibilitas `nodejs_compat`, `GEDUNG_E_ORIGIN` dengan alamat publik di atas, dan nilai `GEDUNG_E_KDF_SALT` serta Secret `GEDUNG_E_APP_KEY` yang sudah dipasang. Nilai tersebut diperlukan untuk mempertahankan sandi petugas yang ada. Secret `GEDUNG_E_ADMIN_SETUP` memuat SHA-256 kode aktivasi pertama diikuti titik dua dan kedaluwarsa Unix dalam detik.

Migrasi skema tersimpan di folder `migrations` dan dicatat dalam tabel `d1_migrations`. Untuk D1 baru, jalankan `npx cf d1 migrations apply <ID_D1>` dari akun Cloudflare yang sesuai, lalu ikat D1 tersebut ke `DB` di pengaturan proyek.

## Kuota gratis

Aset statis Pages gratis. Permintaan dinamis Pages Functions dan Workers berbagi kuota akun Workers Free sebesar 100.000 per hari. D1 Free mendukung hingga 500 MB per basis data. Aplikasi memperkecil foto sebelum mengunggahnya dan menyediakan ruang untuk data laporan serta klaim.

- [Direct Upload Cloudflare Pages](https://developers.cloudflare.com/pages/get-started/direct-upload/)
- [Harga Pages Functions](https://developers.cloudflare.com/pages/functions/pricing/)
- [Batas D1](https://developers.cloudflare.com/d1/platform/limits/)

(() => {
  const themeButtons = document.querySelectorAll('[data-theme-toggle]');
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');

  function preference(key, value) {
    try {
      if (value !== undefined) localStorage.setItem(key, value);
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  function setTheme(dark) {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    for (const button of themeButtons) {
      button.setAttribute('aria-pressed', String(dark));
      button.setAttribute('aria-label', dark ? 'Gunakan tema terang' : 'Gunakan tema gelap');
      button.querySelector('.icon').className = dark ? 'icon icon-sun' : 'icon icon-moon-stars';
    }
  }

  const savedTheme = preference('gedung-e-theme');
  setTheme(savedTheme === 'dark');
  for (const button of themeButtons) {
    button.addEventListener('click', () => {
      const dark = document.documentElement.dataset.theme !== 'dark';
      setTheme(dark);
      preference('gedung-e-theme', dark ? 'dark' : 'light');
    });
  }

  const itemList = document.querySelector('[data-item-list]');
  const viewButtons = [...document.querySelectorAll('[data-view-option]')];
  if (itemList && viewButtons.length) {
    function setView(view) {
      itemList.dataset.view = view;
      for (const button of viewButtons) button.setAttribute('aria-pressed', String(button.dataset.viewOption === view));
    }
    setView(preference('gedung-e-view') === 'grid' ? 'grid' : 'list');
    for (const button of viewButtons) {
      button.addEventListener('click', () => {
        setView(button.dataset.viewOption);
        preference('gedung-e-view', button.dataset.viewOption);
      });
    }
  }

  for (const select of document.querySelectorAll('[data-submit-change]')) {
    select.addEventListener('change', () => select.form.requestSubmit());
  }

  const copyButton = document.querySelector('[data-copy-code]');
  copyButton?.addEventListener('click', async () => {
    const code = document.querySelector('[data-code-text]');
    const live = document.querySelector('[data-copy-status]');
    try {
      await navigator.clipboard.writeText(code.textContent);
      live.textContent = 'Kode pelacakan tersalin.';
    } catch {
      const range = document.createRange();
      range.selectNodeContents(code);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      live.textContent = 'Kode dipilih. Gunakan menu Salin.';
    }
  });

  document.addEventListener('click', event => {
    if (motionPreference.matches || !(event.target instanceof Element)) return;
    const control = event.target.closest('.button, .summary-card, .item-action, .view-options button, .theme-control');
    if (!control || control.matches(':disabled')) return;
    const surface = control.closest('.item-row') || control;
    const bounds = surface.getBoundingClientRect();
    const x = event.detail ? event.clientX - bounds.left : bounds.width / 2;
    const y = event.detail ? event.clientY - bounds.top : bounds.height / 2;
    const diameter = 2 * Math.hypot(Math.max(x, bounds.width - x), Math.max(y, bounds.height - y));
    const wave = document.createElement('span');
    if (!wave.animate) return;
    wave.className = 'tap-wave';
    wave.setAttribute('aria-hidden', 'true');
    wave.style.left = x + 'px';
    wave.style.top = y + 'px';
    wave.style.width = wave.style.height = diameter + 'px';
    surface.append(wave);
    const animation = wave.animate([
      { transform: 'translate(-50%, -50%) scale(0)', opacity: .9 },
      { transform: 'translate(-50%, -50%) scale(1)', opacity: 0 },
    ], { duration: 460, easing: 'cubic-bezier(.2,.7,.3,1)' });
    animation.finished.then(() => wave.remove(), () => wave.remove());
  });

  async function resizedPhoto(file, handover) {
    if (file.size > 12_000_000) throw new Error('file-size');
    const url = URL.createObjectURL(file);
    try {
      const image = new Image();
      image.src = url;
      await image.decode();
      const maxSide = handover ? 64 : 720;
      const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const context = canvas.getContext('2d', { alpha: false });
      context.fillStyle = 'white';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      for (const quality of [.82, .68, .52]) {
        const jpeg = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
        if (jpeg && jpeg.size <= (handover ? 14_000 : 380_000)) {
          return new File([jpeg], 'foto.jpg', { type: 'image/jpeg' });
        }
      }
      throw new Error('image-size');
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  for (const form of document.querySelectorAll('[data-image-form]')) {
    const input = form.querySelector('[data-photo]');
    const message = form.querySelector('[data-photo-error]');
    let converted;
    let busy = false;
    input.addEventListener('change', () => { message.hidden = true; });
    form.addEventListener('submit', async event => {
      const file = input.files[0];
      if (!file || file === converted) return;
      event.preventDefault();
      if (busy) return;
      busy = true;
      input.disabled = true;
      const button = event.submitter;
      if (button) button.disabled = true;
      message.hidden = false;
      message.textContent = 'Menyiapkan foto…';
      let ready = false;
      try {
        const data = new DataTransfer();
        data.items.add(await resizedPhoto(file, input.name === 'handover_photo'));
        input.files = data.files;
        converted = input.files[0];
        ready = true;
        message.hidden = true;
      } catch {
        message.textContent = 'Foto tidak dapat diproses. Pilih foto JPG atau PNG yang lebih kecil, atau lanjutkan tanpa foto.';
      } finally {
        input.disabled = false;
        if (button) button.disabled = false;
        busy = false;
      }
      if (ready) form.requestSubmit(button || undefined);
    });
  }

  async function derivePassword(password, salt) {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
    const bytes = await crypto.subtle.deriveBits({
      name: 'PBKDF2',
      hash: 'SHA-256',
      salt: encoder.encode('Gedung E staff v1:' + salt),
      iterations: 600_000,
    }, key, 256);
    return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, '0')).join('');
  }

  for (const form of document.querySelectorAll('[data-password-form]')) {
    const message = form.querySelector('[data-password-message]');
    const passwords = [...form.querySelectorAll('[data-password-proof]')];
    const confirmation = form.querySelector('[data-password-confirm]');
    let ready = false;
    let busy = false;

    form.addEventListener('submit', async event => {
      if (ready) {
        ready = false;
        return;
      }
      event.preventDefault();
      if (busy) return;
      const newPassword = passwords.find(input => input.dataset.passwordProof === 'new_proof');
      if (confirmation && newPassword.value !== confirmation.value) {
        message.hidden = false;
        message.textContent = 'Ulangi sandi baru yang sama.';
        confirmation.focus();
        return;
      }

      busy = true;
      const button = event.submitter;
      if (button) button.disabled = true;
      message.hidden = false;
      message.textContent = 'Memproses sandi…';
      try {
        const proofs = await Promise.all(passwords.map(input => derivePassword(input.value, form.dataset.salt)));
        for (const [index, input] of passwords.entries()) {
          const name = input.dataset.passwordProof;
          const hidden = form.elements.namedItem(name) || document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = name;
          hidden.value = proofs[index];
          if (!hidden.parentNode) form.append(hidden);
        }
        ready = true;
      } catch {
        message.textContent = 'Sandi belum bisa diproses. Buka situs ini di Safari atau Chrome dan coba lagi.';
      } finally {
        busy = false;
        if (button) button.disabled = false;
      }
      if (ready) form.requestSubmit(button || undefined);
    });
  }
})();

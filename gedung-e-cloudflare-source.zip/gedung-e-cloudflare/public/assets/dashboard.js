(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const bar = document.querySelector('.dashboard-bar');
  const dock = document.querySelector('.dashboard-dock');
  const viewport = window.visualViewport;

  const dismiss = document.querySelector('[data-bar-dismiss]');
  if (dismiss) {
    dismiss.hidden = false;
    dismiss.addEventListener('click', () => {
      document.querySelector('[data-bar-notice]').hidden = true;
    });
  }

  const focus = document.querySelector('[data-focus-toggle]');
  if (focus) {
    focus.hidden = false;
    focus.addEventListener('click', () => {
      const focused = document.body.toggleAttribute('data-focus');
      focus.setAttribute('aria-pressed', String(focused));
      focus.setAttribute('aria-label', focused ? 'Mode fokus: tampilkan navigasi' : 'Mode fokus: sembunyikan navigasi');
    });
  }

  function clamp(value, minimum, maximum) {
    return Math.min(Math.max(value, minimum), Math.max(minimum, maximum));
  }

  const search = document.querySelector('[data-search-dialog]');
  const tour = document.querySelector('[data-dashboard-tour]');
  function openSearch() {
    if (!search?.showModal || search.open || tour?.open) return false;
    search.showModal();
    return true;
  }

  for (const trigger of document.querySelectorAll('[data-search-open]')) {
    trigger.addEventListener('click', event => {
      if (!event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey && openSearch()) {
        event.preventDefault();
      }
    });
  }

  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k' && openSearch()) {
      event.preventDefault();
    }
  });

  if (tour?.showModal) {
    const seenKey = 'gedung-e-dashboard-tour-v1';
    const replay = document.querySelector('[data-tour-open]');
    const aside = document.querySelector('.dashboard-aside');
    const template = tour.querySelector('[data-tour-steps]');
    const steps = [...template.content.children];
    const mask = tour.querySelector('[data-tour-mask]');
    const card = tour.querySelector('[data-tour-card]');
    const counter = tour.querySelector('[data-tour-counter]');
    const title = tour.querySelector('[data-tour-title]');
    const copy = tour.querySelector('[data-tour-copy]');
    const dots = [...tour.querySelectorAll('.tour-dots span')];
    const previous = tour.querySelector('[data-tour-previous]');
    const next = tour.querySelector('[data-tour-next]');
    const nextLabel = next.querySelector('span');
    let index = 0;
    let target;
    let initialScroll = 0;
    let initialAsideScroll = 0;
    let frame = 0;
    let automatic;

    function limits() {
      const width = viewport?.width ?? window.innerWidth;
      const height = viewport?.height ?? window.innerHeight;
      const top = Math.max(14, bar.getBoundingClientRect().bottom + 8);
      const bottom = Math.min(height - 14, dock.offsetHeight ? dock.getBoundingClientRect().top - 8 : height);
      return bottom - top < 240 && height < 500 ? { width, top: 14, bottom: height - 14 } : { width, top, bottom };
    }

    function position() {
      frame = 0;
      if (!tour.open) return;
      const { width, top, bottom } = limits();
      const cardWidth = card.offsetWidth;
      const cardHeight = card.offsetHeight;
      const leftLimit = 14;
      const rightLimit = width - 18;
      const range = target?.getBoundingClientRect();
      let left = (width - cardWidth) / 2;
      let y = (top + bottom - cardHeight) / 2;
      let placement = 'welcome';

      if (range) {
        const asideBounds = aside?.contains(target) ? aside.getBoundingClientRect() : null;
        const upper = Math.max(top, range.top - 4, asideBounds?.top ?? top);
        const lower = Math.min(bottom, range.bottom + 4, asideBounds?.bottom ?? bottom);
        const start = Math.max(leftLimit, range.left - 4);
        const end = Math.min(rightLimit, range.right + 4);
        mask.toggleAttribute('data-spotlight', lower > upper && end > start);
        if (mask.hasAttribute('data-spotlight')) {
          mask.style.left = start + 'px';
          mask.style.top = upper + 'px';
          mask.style.width = end - start + 'px';
          mask.style.height = lower - upper + 'px';
          left = start + Math.min(15, (end - start) / 5);
          if (bottom - lower >= cardHeight + 18) {
            y = lower + 16;
            placement = 'below';
          } else if (upper - top >= cardHeight + 18) {
            y = upper - cardHeight - 16;
            placement = 'above';
          } else {
            const preferTop = lower > top + (bottom - top) / 2;
            y = preferTop ? top : bottom - cardHeight;
            placement = 'overlay';
          }
        } else {
          mask.removeAttribute('style');
          placement = 'overlay';
        }
      } else {
        mask.removeAttribute('data-spotlight');
        mask.removeAttribute('style');
        if (width > 720) left -= 27;
      }

      card.dataset.placement = placement;
      card.style.left = clamp(left, leftLimit, rightLimit - cardWidth) + 'px';
      card.style.top = clamp(y, top, bottom - cardHeight) + 'px';
    }

    function requestPosition() {
      if (tour.open && !frame) frame = window.requestAnimationFrame(position);
    }

    function showStep(stepIndex) {
      index = stepIndex;
      const step = steps[index];
      const key = step.dataset.target;
      const targets = key ? document.querySelectorAll('[data-tour-target="' + key + '"]') : [];
      target = Array.from(targets).find(element => element.getClientRects().length);
      if (target && window.matchMedia('(max-width: 720px)').matches) {
        target = target.querySelector('[data-tour-focus]') || target;
      }
      counter.textContent = 'Tur beranda · ' + (index + 1) + ' / ' + steps.length;
      title.textContent = step.querySelector('strong').textContent;
      copy.textContent = step.querySelector('p').textContent;
      dots.forEach((dot, dotIndex) => {
        dot.toggleAttribute('data-active', dotIndex === index);
        dot.toggleAttribute('data-passed', dotIndex < index);
      });
      previous.textContent = index ? 'Kembali' : 'Nanti saja';
      nextLabel.textContent = index === steps.length - 1 ? 'Selesai' : index ? 'Lanjut' : 'Ayo!';

      if (target) {
        if (aside?.contains(target) && aside.scrollHeight > aside.clientHeight) {
          const bounds = aside.getBoundingClientRect();
          const targetBounds = target.getBoundingClientRect();
          if (targetBounds.top < bounds.top || targetBounds.bottom > bounds.bottom) {
            aside.scrollTop += targetBounds.top - bounds.top - 12;
          }
        }
        const { top, bottom } = limits();
        const range = target.getBoundingClientRect();
        const desired = top + Math.max(7, (bottom - top - range.height - card.offsetHeight - 20) / 2);
        if (range.top < top || range.bottom > bottom || range.height + card.offsetHeight + 20 > bottom - top) {
          window.scrollBy({ top: range.top - desired, behavior: 'instant' });
        }
      } else {
        window.scrollTo({ top: initialScroll, behavior: 'instant' });
      }
      position();
      next.focus({ preventScroll: true });
    }

    function openTour() {
      if (tour.open || search?.open) return;
      clearTimeout(automatic);
      initialScroll = window.scrollY;
      initialAsideScroll = aside?.scrollTop ?? 0;
      tour.showModal();
      showStep(0);
    }

    replay.hidden = false;
    replay.addEventListener('click', openTour);
    previous.addEventListener('click', () => index ? showStep(index - 1) : tour.close());
    next.addEventListener('click', () => index < steps.length - 1 ? showStep(index + 1) : tour.close());
    tour.querySelector('[data-tour-close]').addEventListener('click', () => tour.close());
    tour.addEventListener('close', () => {
      try {
        localStorage.setItem(seenKey, '1');
      } catch {
        // Replay remains available when storage is disabled.
      }
      window.scrollTo({ top: initialScroll, behavior: 'instant' });
      if (aside) aside.scrollTop = initialAsideScroll;
      replay.focus({ preventScroll: true });
    });

    window.addEventListener('resize', requestPosition);
    window.addEventListener('scroll', requestPosition, { passive: true });
    viewport?.addEventListener('resize', requestPosition);

    function isFirstVisit() {
      try {
        return localStorage.getItem(seenKey) !== '1';
      } catch {
        return false;
      }
    }

    if (!location.search && !location.hash && isFirstVisit()) {
      automatic = window.setTimeout(() => {
        const focused = document.activeElement;
        if (document.visibilityState === 'visible' && !location.hash && window.scrollY < 16 &&
            (focused === document.body || focused === document.documentElement) && isFirstVisit()) {
          openTour();
        }
      }, 4600);
    }
  }

  const journey = document.querySelector('[data-journey]');
  if (journey) {
    const steps = [...journey.querySelectorAll('[data-journey-step]')];
    const stops = [...journey.querySelectorAll('[data-stage-stop]')];
    const scenes = [...journey.querySelectorAll('[data-board-scene]')];
    const board = journey.querySelector('.journey-board');
    const fill = journey.querySelector('[data-journey-fill]');
    const count = journey.querySelector('[data-journey-count]');
    const progress = journey.querySelector('[data-journey-progress]');
    let active = 0;
    let frame = 0;

    function showStage(nextIndex) {
      active = nextIndex;
      count.textContent = (active + 1) + ' / ' + steps.length;
      steps.forEach((step, index) => {
        const current = index === active;
        const stop = stops[index];
        step.toggleAttribute('data-passed', index < active);
        stop.toggleAttribute('data-passed', index < active);
        if (current) {
          step.setAttribute('aria-current', 'step');
          stop.setAttribute('aria-current', 'step');
        } else {
          step.removeAttribute('aria-current');
          stop.removeAttribute('aria-current');
        }
        scenes[index].hidden = !current;
      });
    }

    function updateJourney() {
      frame = 0;
      const height = viewport?.height ?? window.innerHeight;
      const stacked = window.getComputedStyle(journey).gridTemplateColumns.split(' ').length === 1;
      const barBottom = bar.getBoundingClientRect().bottom;
      const boardBottom = getComputedStyle(board.parentElement).position === 'sticky'
        ? board.getBoundingClientRect().bottom : barBottom;
      const line = stacked
        ? clamp(boardBottom + 44, Math.max(height * .38, barBottom + 28), height - 74)
        : Math.max(barBottom + 52, height * .39);
      const positions = steps.map(step => step.getBoundingClientRect().top);
      const last = positions.length - 1;
      let nextIndex = 0;
      for (let index = 1; index <= last; index++) {
        if (positions[index] <= line) nextIndex = index;
      }
      const bottom = window.scrollY > 0 && window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2;
      if (bottom) nextIndex = last;
      if (nextIndex !== active) showStage(nextIndex);

      const portion = bottom ? 1 : clamp((line - positions[0]) / (positions[last] - positions[0]), 0, 1);
      fill.style.transform = 'scaleX(' + portion + ')';
      progress.setAttribute('aria-valuenow', String(Math.round(portion * 100)));
    }

    function requestJourneyUpdate() {
      if (!frame) frame = window.requestAnimationFrame(updateJourney);
    }

    function updateHash() {
      if (steps.some(step => '#' + step.id === location.hash)) requestJourneyUpdate();
    }

    journey.addEventListener('click', event => {
      const stop = event.target instanceof Element && event.target.closest('[data-stage-stop]');
      if (!stop || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const index = stops.indexOf(stop);
      event.preventDefault();
      if (location.hash !== stop.hash) history.pushState(null, '', stop.hash);
      steps[index].scrollIntoView({ block: 'start', behavior: reducedMotion.matches ? 'instant' : 'smooth' });
    });

    journey.dataset.journeyReady = '';
    window.addEventListener('scroll', requestJourneyUpdate, { passive: true });
    window.addEventListener('resize', requestJourneyUpdate);
    window.addEventListener('hashchange', updateHash);
    window.addEventListener('pageshow', requestJourneyUpdate);
    viewport?.addEventListener('resize', requestJourneyUpdate);
    requestJourneyUpdate();
  }
})();

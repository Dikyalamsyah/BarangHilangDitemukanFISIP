const encoder = new TextEncoder();
const MAX_FORM_BYTES = 410_000;

export class RequestError extends Error {
  constructor(readonly status: number, message: string, readonly back = "/") {
    super(message);
  }
}

export function isId(value: string | undefined): value is string {
  return typeof value === "string" && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(value);
}

export function checkOrigin(request: Request, configuredOrigin?: string) {
  const siteOrigin = configuredOrigin || new URL(request.url).origin;
  if (request.headers.get("Origin") !== siteOrigin) {
    throw new RequestError(403, "Kirim formulir dari halaman situs Gedung E.");
  }
}

export async function readForm(request: Request, back: string, maxBytes = MAX_FORM_BYTES) {
  const type = request.headers.get("Content-Type") || "";
  if (!/^(multipart\/form-data|application\/x-www-form-urlencoded)(;|$)/i.test(type) || !request.body) {
    throw new RequestError(400, "Formulir tidak dapat dibaca.", back);
  }
  const oversized = new RequestError(413, "Ukuran foto terlalu besar. Pilih foto yang lebih kecil.", back);
  if (Number(request.headers.get("Content-Length")) > maxBytes) throw oversized;
  const parts: BlobPart[] = [];
  const reader = request.body.getReader();
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) {
        await reader.cancel();
        throw oversized;
      }
      parts.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  try {
    return await new Response(new Blob(parts), { headers: { "Content-Type": type } }).formData();
  } catch {
    throw new RequestError(400, "Formulir tidak dapat dibaca. Silakan coba lagi.", back);
  }
}

export function field(form: FormData, name: string, label: string, max: number, back: string, required = true) {
  const entry = form.get(name);
  const value = typeof entry === "string" ? entry.trim() : "";
  if (required && !value) throw new RequestError(400, `Isi ${label}.`, back);
  if (value.length > max) throw new RequestError(400, `${label} maksimal ${max} karakter.`, back);
  return value;
}

export function nonce(form: FormData, back: string) {
  const key = field(form, "request_key", "kode formulir", 36, back);
  if (!isId(key)) throw new RequestError(400, "Buka ulang formulir untuk melanjutkan.", back);
  return key;
}

function hex(bytes: ArrayBuffer) {
  return Array.from(new Uint8Array(bytes), value => value.toString(16).padStart(2, "0")).join("");
}

export async function digest(value: string) {
  return hex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

export async function keyedHash(secret: string | undefined, value: string) {
  if (!secret || secret.length < 32) throw new RequestError(503, "Layanan belum siap menerima formulir. Coba lagi nanti.");
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}

export async function rateLimit(request: Request, db: D1Database, secret: string | undefined, scope: string, limit: number, seconds: number, back: string) {
  const now = Math.floor(Date.now() / 1000);
  const window = Math.floor(now / seconds);
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const key = await keyedHash(secret, `rate:${scope}:${window}:${ip}`);
  const entry = await db.prepare(`
    INSERT INTO request_limits (key,expires_at,count) VALUES (?,?,1)
    ON CONFLICT(key) DO UPDATE SET count=count+1 WHERE count < ?
    RETURNING count
  `).bind(key, (window + 1) * seconds, limit).first();
  if (!entry) throw new RequestError(429, "Terlalu banyak percobaan. Silakan coba lagi nanti.", back);
  if (crypto.getRandomValues(new Uint8Array(1))[0] < 12) {
    await db.prepare(`
      DELETE FROM request_limits WHERE key IN (
        SELECT key FROM request_limits WHERE expires_at < ? LIMIT 200
      )
    `).bind(now).run();
  }
}

export const securityHeaders = {
  "Cache-Control": "no-store",
  "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  "Referrer-Policy": "same-origin",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
};

export function html(content: string, status = 200) {
  return new Response(content, { status, headers: { ...securityHeaders, "Content-Type": "text/html; charset=utf-8" } });
}

export function redirect(path: string, cookie?: string) {
  const headers = new Headers({ ...securityHeaders, Location: path });
  if (cookie) headers.set("Set-Cookie", cookie);
  return new Response(null, { status: 303, headers });
}

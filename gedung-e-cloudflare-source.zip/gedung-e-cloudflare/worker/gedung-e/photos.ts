import jpeg from "jpeg-js";
import { RequestError, securityHeaders } from "./http";
import { stripJpegMetadata } from "./jpeg-scrub";

export async function preparePhoto(form: FormData, field: string, back: string, blur = false) {
  const file = form.get(field);
  if (file == null || (file instanceof File && file.size === 0)) return null;
  if (!(file instanceof File) || file.size > (blur ? 14_000 : 380_000)) {
    throw new RequestError(413, "Foto terlalu besar. Pilih ulang foto melalui formulir.", back);
  }

  try {
    const bytes = stripJpegMetadata(new Uint8Array(await file.arrayBuffer()), blur ? 64 : 960);
    if (!blur) return bytes;

    const image = jpeg.decode(bytes, {
      useTArray: true, maxResolutionInMP: 0.005, maxMemoryUsageInMB: 3, tolerantDecoding: false,
    });
    const side = Math.max(image.width, image.height);
    const width = Math.min(image.width, Math.max(1, Math.round(8 * image.width / side)));
    const height = Math.min(image.height, Math.max(1, Math.round(8 * image.height / side)));
    const sums = Array.from({ length: width * height }, () => [0, 0, 0, 0]);

    for (let y = 0; y < image.height; y++) {
      for (let x = 0; x < image.width; x++) {
        const sum = sums[Math.floor(y * height / image.height) * width + Math.floor(x * width / image.width)];
        const offset = 4 * (y * image.width + x);
        sum[0] += image.data[offset];
        sum[1] += image.data[offset + 1];
        sum[2] += image.data[offset + 2];
        sum[3]++;
      }
    }

    const data = new Uint8Array(4 * width * height);
    for (const [i, sum] of sums.entries()) {
      data[4 * i] = sum[0] / sum[3];
      data[4 * i + 1] = sum[1] / sum[3];
      data[4 * i + 2] = sum[2] / sum[3];
      data[4 * i + 3] = 255;
    }
    // Encode new pixels, with at most eight cells on either side. Only this
    // image is stored or served. Browsers interpolate it to display size.
    return new Uint8Array(jpeg.encode({ data, width, height }, 72).data);
  } catch {
    throw new RequestError(400, "Foto tidak bisa diproses. Pilih ulang JPG atau PNG melalui formulir.", back);
  }
}

export async function writeWithPhoto(db: D1Database, statements: D1PreparedStatement[], back: string) {
  try {
    return await db.batch(statements);
  } catch (error) {
    if (error instanceof Error && error.message.includes("gedung_e_photo_limit")) {
      throw new RequestError(413, "Ruang foto sudah penuh. Anda bisa melanjutkan tanpa foto.", back);
    }
    throw error;
  }
}

export function photoResponse(bytes?: number[] | null) {
  if (!bytes) return new Response(null, { status: 404, headers: securityHeaders });
  return new Response(Uint8Array.from(bytes), { headers: { ...securityHeaders, "Content-Type": "image/jpeg" } });
}

import { esc, icon, link } from "./markup";
import type { HomeSummary } from "./types";

export function pageSwitch(active: "/" | "/alur") {
  return `<nav class="page-switch" aria-label="Beranda dan alur" data-tour-target="alur">
    <a href="/"${active === "/" ? ' aria-current="page"' : ""}>${icon("grid-1x2")}Beranda</a>
    <a href="/alur"${active === "/alur" ? ' aria-current="page"' : ""}>${icon("geo-alt")}Alur</a>
  </nav>`;
}

const quickLinks = [
  { href: "/laporkan", title: "Buat laporan barang", hint: "Mulai di sini" },
  { href: "#daftar-barang", title: "Cari di daftar barang", hint: "Lihat daftar" },
  { href: "/cek-klaim", title: "Lacak pengajuan klaim", hint: "Cek status" },
];

const weekday = new Intl.DateTimeFormat("id-ID", { weekday: "short", timeZone: "UTC" });
const dateLabel = new Intl.DateTimeFormat("id-ID", { dateStyle: "long", timeZone: "UTC" });

function activityCard({ found, lost, recent }: HomeSummary) {
  return `<section class="paper-card dashboard-counts" data-tour-target="ringkasan" aria-labelledby="ringkasan-title">
    <div class="activity-heading">
      <span class="sticker sticker-paper">${icon("inbox")}</span>
      <div><h2 id="ringkasan-title">Laporan barang</h2><p><strong>${found + lost}</strong> aktif</p></div>
    </div>
    <ol class="activity-days" aria-label="Laporan ditayangkan dalam tujuh hari terakhir">
      ${recent.map(({ date, count }, index) => {
        const day = new Date(date);
        const label = `${dateLabel.format(day)}, ${count} laporan ditayangkan`;
        return `<li${index === recent.length - 1 ? ' class="activity-today"' : ""} title="${esc(label)}">
          <span class="activity-dot${count ? " has-activity" : ""}" aria-hidden="true">${icon(count ? "check2-circle" : "inbox")}</span>
          <time datetime="${date}">${weekday.format(day)}</time><span class="visually-hidden">, ${count} laporan ditayangkan</span>
        </li>`;
      }).join("")}
    </ol>
    <p class="activity-caption">Laporan tampil setelah petugas Gedung E meninjaunya.</p>
    <div class="count-links" aria-label="Saring laporan aktif">
      <a href="/?kind=found#daftar-barang"><span>Barang temuan</span><strong>${found}</strong></a>
      <a href="/?kind=lost#daftar-barang"><span>Laporan hilang</span><strong>${lost}</strong></a>
    </div>
  </section>`;
}

export function dashboardIntro(counts: HomeSummary) {
  return `<div class="dashboard-grid">
    <div class="dashboard-primary">
      <header class="home-heading dashboard-heading">
        <p class="home-eyebrow">${icon("box-seam")} Barang hilang &amp; ditemukan</p>
        <div class="home-title-line">
          <h1>Halo, warga <mark>Gedung E</mark>.</h1>
          <div class="home-heading-actions">
            <button class="home-focus" type="button" data-focus-toggle aria-controls="desktop-navigation mobile-navigation" aria-pressed="false" aria-label="Mode fokus: sembunyikan navigasi" title="Mode fokus" hidden>${icon("grid-1x2")}</button>
            ${pageSwitch("/")}
          </div>
        </div>
        <p>Layanan barang hilang &amp; ditemukan FISIP UI.</p>
      </header>
      <div class="dashboard-continue">
        <button class="guide-replay" type="button" data-tour-open aria-haspopup="dialog" aria-controls="dashboard-tour" hidden>
          <span class="guide-caption"><span>Bingung mulai dari mana?</span><strong>Ayo ikut tur 30 detik!</strong></span>
          <span class="guide-mascot" aria-hidden="true">
            <img src="/assets/guide-parcel.webp" width="94" height="94" alt="" decoding="async">
            <span class="guide-question">?</span>
          </span>
        </button>
        <section class="paper-card dashboard-start" data-tour-target="mulai" aria-labelledby="mulai-title">
          <div class="start-art dot-paper">
            <span class="paper-tag" aria-hidden="true">Gedung E</span>
            <span class="start-counter" aria-label="${counts.found + counts.lost} laporan aktif">
              <span class="start-counter-ring"><span class="map-pulse" aria-hidden="true"></span><strong>${counts.found + counts.lost}</strong><small>aktif</small></span>
            </span>
          </div>
          <div class="start-content">
            <p class="card-eyebrow">Layanan pelaporan</p>
            <h2 id="mulai-title">Laporkan barang</h2>
            <p class="start-description">Barang hilang atau ditemukan di Gedung E.</p>
            <ol class="quick-links" data-tour-focus>
              ${quickLinks.map(({ href, title, hint }, index) => `<li><a href="${href}">
                <span class="quick-number" aria-hidden="true">${index + 1}</span><strong>${title}</strong><small>${hint}</small>
              </a></li>`).join("")}
            </ol>
            <a class="button button-primary start-report" href="/laporkan"><span>Lapor</span>${icon("arrow-right")}</a>
            <p class="start-footnote">Jika menemukan barang, titipkan kepada petugas Gedung E.</p>
          </div>
        </section>
      </div>
    </div>
    <aside class="dashboard-aside" aria-label="Ringkasan dan akses cepat">
      ${activityCard(counts)}
      <section class="paper-card dashboard-journey-summary" aria-labelledby="alur-ringkas-title">
        <div class="journey-mini-heading"><h2 id="alur-ringkas-title">Alur pengembalian</h2><strong aria-label="${stages.length} tahap">${stages.length}<small> tahap</small></strong></div>
        <ol class="journey-mini-steps">
          ${stages.map(({ id, label, preview, tone }, index) => `<li><a href="/alur#${id}">
            <span class="mini-step-number sticker-${tone}" aria-hidden="true">${stageNumber(index + 1)}</span>
            <span><strong>${label}</strong><small>${preview}</small></span>
          </a></li>`).join("")}
        </ol>
        <a class="button button-secondary" href="/alur" data-tour-target="alur"><span>Lihat di Alur</span>${icon("arrow-right")}</a>
      </section>
      <section class="paper-card dashboard-shortcut shortcut-claim" data-tour-target="klaim" aria-labelledby="lacak-title">
        <span class="sticker sticker-lavender">${icon("clipboard")}</span>
        <div><h2 id="lacak-title">Lacak klaim</h2><p>Gunakan kode pelacakan untuk melihat status klaim.</p></div>
        ${link("/cek-klaim", "Cek klaim", "secondary", "arrow-right")}
      </section>
      <section class="paper-card dashboard-shortcut shortcut-history" aria-labelledby="history-shortcut-title">
        <span class="sticker sticker-mint">${icon("clock-history")}</span>
        <div><h2 id="history-shortcut-title">Histori serah terima</h2><p>Lihat barang yang sudah dikembalikan.</p></div>
        ${link("/histori", "Buka histori", "secondary", "arrow-right")}
      </section>
    </aside>
  </div>`;
}

const tourSteps = [
  { target: "", title: "Halo, selamat datang!", copy: "Kenali tempat mencari, melaporkan, dan mengambil barang di Gedung E. Ikuti tur singkatnya." },
  { target: "mulai", title: "Mulai dari kartu ini", copy: "Tekan Lapor untuk membuka formulir. Dari kartu ini Anda juga bisa mencari barang dan melacak klaim." },
  { target: "ringkasan", title: "Lihat ringkasan barang", copy: "Ketuk salah satu angka untuk menyaring daftar barang temuan atau laporan kehilangan." },
  { target: "daftar", title: "Temukan barang Anda", copy: "Cari nama atau lokasi barang dan gunakan filter kategori untuk mempersempit hasil." },
  { target: "klaim", title: "Lacak pengajuan klaim", copy: "Masukkan kode pelacakan yang Anda dapat saat mengajukan klaim untuk melihat statusnya." },
  { target: "alur", title: "Ikuti alur pengembalian", copy: "Buka Alur untuk melihat langkah pengembalian sampai barang diserahkan ke pemilik." },
];

export function dashboardTour() {
  return `<dialog class="dashboard-tour" id="dashboard-tour" data-dashboard-tour aria-labelledby="tour-title" aria-describedby="tour-description">
    <div class="tour-mask" data-tour-mask aria-hidden="true"></div>
    <div class="tour-card" data-tour-card>
      <img class="tour-mascot" src="/assets/guide-parcel.webp" width="80" height="80" alt="" decoding="async">
      <button class="tour-close" type="button" aria-label="Tutup tur" data-tour-close>${icon("x-lg")}</button>
      <p class="tour-counter" data-tour-counter></p>
      <div aria-live="polite" aria-atomic="true">
        <h2 id="tour-title" data-tour-title>${tourSteps[0].title}</h2>
        <p id="tour-description" data-tour-copy>${tourSteps[0].copy}</p>
      </div>
      <div class="tour-dots" aria-hidden="true">${tourSteps.map(() => "<span></span>").join("")}</div>
      <div class="tour-actions">
        <button class="tour-previous" type="button" data-tour-previous>Nanti saja</button>
        <button class="button button-primary" type="button" data-tour-next autofocus><span>Ayo!</span>${icon("arrow-right")}</button>
      </div>
    </div>
    <template data-tour-steps>${tourSteps.map(({ target, title, copy }) =>
      `<div data-target="${target}"><strong>${esc(title)}</strong><p>${esc(copy)}</p></div>`).join("")}</template>
  </dialog>`;
}

const stages = [
  {
    id: "cari", label: "Cari barang", title: "Cek daftar barang",
    copy: "Jika barang Anda hilang, cari dulu di daftar temuan Gedung E. Gunakan kata kunci, lokasi, atau kategori.",
    note: "Kalau barang sudah tercantum, buka detailnya untuk mengajukan klaim.",
    glyph: "search", tone: "mint", preview: "Pencarian barang", detail: "Nama barang, lokasi, atau kategori",
    labels: ["Cari kata kunci", "Saring kategori", "Buka detail"], href: "/#daftar-barang", action: "Cari barang",
  },
  {
    id: "lapor", label: "Lapor", title: "Laporkan barang",
    copy: "Buat laporan jika Anda menemukan barang atau barang Anda belum tercantum. Isi nama barang, lokasi, dan ciri umumnya.",
    note: "Jika Anda menemukan barang, titipkan kepada petugas Gedung E.",
    glyph: "plus-square", tone: "peach", preview: "Laporan barang", detail: "Sertakan lokasi dan ciri umum",
    labels: ["Pilih jenis laporan", "Isi rincian barang", "Kirim laporan"], href: "/laporkan", action: "Buat laporan",
  },
  {
    id: "tinjau", label: "Tinjau", title: "Petugas meninjau laporan",
    copy: "Petugas Gedung E memeriksa rincian barang sebelum menayangkan laporan di daftar publik.",
    note: "Setelah tayang, barang temuan bisa diklaim dari halaman detailnya.",
    glyph: "shield-check", tone: "lavender", preview: "Tinjauan petugas", detail: "Laporan tampil setelah disetujui",
    labels: ["Laporan diterima", "Rincian diperiksa", "Laporan ditayangkan"], href: "/#daftar-barang", action: "Lihat barang yang tayang",
  },
  {
    id: "klaim", label: "Klaim", title: "Ajukan dan lacak klaim",
    copy: "Buka detail barang temuan dan jelaskan ciri yang hanya diketahui pemilik. Simpan kode pelacakan setelah mengirim klaim.",
    note: "Jika klaim disetujui, status berubah menjadi Siap diambil dan petunjuk pengambilan muncul.",
    glyph: "clipboard", tone: "sky", preview: "Pelacakan klaim", detail: "Cek status dengan kode pelacakan",
    labels: ["Ajukan klaim", "Simpan kode", "Cek status"], href: "/cek-klaim", action: "Cek klaim",
  },
  {
    id: "serah-terima", label: "Serah terima", title: "Ambil barang Anda",
    copy: "Ikuti petunjuk pengambilan dan temui petugas Gedung E. Petugas memeriksa bukti kepemilikan sebelum menyerahkan barang.",
    note: "Histori publik mencatat serah terima. Jika petugas menambahkan foto dokumentasi, versi publiknya diburamkan.",
    glyph: "check2-circle", tone: "lime", preview: "Serah terima tercatat", detail: "Histori publik Gedung E",
    labels: ["Ikuti petunjuk", "Ambil barang", "Lihat histori"], href: "/histori", action: "Buka histori",
  },
];

function stageNumber(index: number) {
  return String(index).padStart(2, "0");
}

export function journeyContent() {
  return `
  <header class="dashboard-heading">
    <p class="dashboard-location">${icon("geo-alt")} Gedung E, FISIP UI</p>
    <h1>Alur <mark>pengembalian.</mark></h1>
    <p>Ikuti perjalanan barang dari laporan hingga kembali ke pemilik.</p>
  </header>
  <div class="dashboard-controls">${pageSwitch("/alur")}</div>
  <section class="paper-card journey-banner" aria-labelledby="journey-banner-title">
    <span class="sticker sticker-lime">${icon("geo-alt")}</span>
    <div><h2 id="journey-banner-title">Panduan pengembalian barang</h2><p>Gulir untuk mengikuti tahapnya atau pilih titik yang ingin Anda baca.</p></div>
    ${link("#cari", "Mulai dari sini", "primary", "arrow-right")}
  </section>
  <section class="journey-layout" data-journey aria-label="Tahapan pengembalian barang">
    <aside class="journey-sticky" aria-label="Navigasi tahapan">
      <div class="paper-card journey-board dot-paper">
        <div class="board-heading"><span>${icon("geo-alt")} Alur Gedung E</span><span data-journey-count>1 / ${stages.length}</span></div>
        <nav class="stage-progress" aria-label="Lompat ke tahap">
          ${stages.map(({ id, label }, index) => `<a href="#${id}" class="stage-stop" data-stage-stop ${index === 0 ? 'aria-current="step"' : ""} aria-label="Tahap ${index + 1}, ${label}">
            <span>${stageNumber(index)}</span><small>${label}</small></a>`).join("")}
        </nav>
        <div class="board-scenes" aria-hidden="true">
          ${stages.map(({ glyph, tone, preview, detail, labels }, index) => `<div class="board-scene scene-${tone}" data-board-scene${index ? " hidden" : ""}>
            <span class="paper-tag">Tahap ${stageNumber(index)}</span>
            <div class="scene-heading"><span class="sticker sticker-${tone}">${icon(glyph)}</span><div><strong>${preview}</strong><small>${detail}</small></div></div>
            <ul>${labels.map(label => `<li>${icon("check2")} ${label}</li>`).join("")}</ul>
          </div>`).join("")}
        </div>
        <div class="board-meter" role="progressbar" aria-label="Progres membaca alur" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" data-journey-progress>
          <span data-journey-fill></span>
        </div>
      </div>
    </aside>
    <ol class="journey-steps">
      ${stages.map(({ id, label, title, copy, note, glyph, tone, href, action }, index) =>
        `<li id="${id}" class="journey-step" data-journey-step${index === 0 ? ' aria-current="step"' : ""}>
          <span class="journey-pin" aria-hidden="true">${icon(glyph)}</span>
          <article class="paper-card journey-note note-${tone}">
            <span class="paper-tag">${stageNumber(index)} · ${label}</span>
            <h2>${title}</h2><p>${copy}</p><p class="step-detail">${note}</p>
            ${link(href, action, "secondary", "arrow-right")}
          </article>
        </li>`).join("")}
    </ol>
  </section>`;
}

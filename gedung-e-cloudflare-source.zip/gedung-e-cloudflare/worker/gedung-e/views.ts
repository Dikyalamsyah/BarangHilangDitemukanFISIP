import { categories, type Claim, type ClaimState, type HistoryEntry, type HomeSummary, type PublicReport, type StaffReport, type TrackedClaim } from "./types";

import { esc, icon, link } from "./markup";
import { dashboardIntro, dashboardTour, journeyContent } from "./guide";

function submit(label: string, glyph = "", variant = "primary") {
  return `<button class="button button-${variant}" type="submit">${glyph ? icon(glyph) : ""}<span>${esc(label)}</span></button>`;
}

function panel(title: string, content: string, extra = "") {
  return `<section class="surface form-panel ${extra}"><h2>${esc(title)}</h2>${content}</section>`;
}

function heading(title: string, description = "", back = "", backLabel = "Daftar barang") {
  return `<header class="page-heading"><div>${back ? `<a class="back-link" href="${esc(back)}">${icon("chevron-left")}${esc(backLabel)}</a>` : ""}
    <h1>${esc(title)}</h1>${description ? `<p>${esc(description)}</p>` : ""}</div></header>`;
}

export function layout(title: string, main: string, active = "", staff = false) {
  const groups = [
    { label: "Gedung E", items: [
      ["/", "Beranda", "grid", "lime"],
      ["/alur", "Alur", "geo-alt", "sky"],
      ["/laporkan", "Lapor", "plus-square", "peach"],
      ["/cek-klaim", "Cek klaim", "clipboard", "lime"],
    ] },
    { label: "Daftar barang", items: [
      ["/#daftar-barang", "Semua barang", "list-ul", "mint"],
      ["/?kind=found#daftar-barang", "Barang temuan", "inbox", "lavender"],
      ["/?kind=lost#daftar-barang", "Laporan hilang", "search", "sky"],
    ] },
    { label: "Informasi", items: [
      ["/histori", "Histori serah terima", "clock-history", "peach"],
      ["/privasi", "Privasi", "shield-check", "mint"],
    ] },
  ];
  const dockItems = [
    ["/", "Beranda", "grid"],
    ["/alur", "Alur", "geo-alt"],
    ["/laporkan", "Lapor", ""],
    ["/histori", "Histori", "clock-history"],
    ["/admin", "Petugas", ""],
  ];
  const current = (href: string) => active === href ? ' aria-current="page"' : "";
  const brand = `<a class="dashboard-brand" href="/" aria-label="Beranda Gedung E FISIP UI"><span class="brand-emblem">${icon("box-seam")}</span><strong>Gedung E</strong></a>`;
  const avatar = '<span class="staff-avatar" aria-hidden="true"><span class="map-pulse"></span></span>';
  const themeToggle = `<button class="theme-control" type="button" aria-label="Gunakan tema gelap" aria-pressed="false" data-theme-toggle>${icon("moon-stars")}<span>Tema</span></button>`;
  return `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#142a23">
<meta name="robots" content="noindex, nofollow">
<title>${esc(title)} · Gedung E FISIP UI</title>
<link rel="preload" href="/assets/icons.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/assets/bootstrap.min.css">
<link rel="stylesheet" href="/assets/icons.css">
<link rel="stylesheet" href="/assets/gedung-e.css?v=3">
<link rel="stylesheet" href="/assets/dashboard.css?v=3">
<script src="/assets/gedung-e.js?v=4" defer></script>
<script src="/assets/dashboard.js?v=3" defer></script>
</head>
<body>
<a class="skip-link" href="#main-content">Lewati ke isi utama</a>
<aside class="dashboard-rail" id="desktop-navigation">
  ${brand}
  <a class="rail-search" href="/#daftar-barang" aria-label="Cari barang" data-search-open><span class="sticker sticker-paper">${icon("search")}</span><span>Cari…</span><kbd aria-hidden="true">⌘K</kbd></a>
  <nav class="rail-groups" aria-label="Navigasi utama">
    ${groups.map(({ label, items }) => `<div class="rail-group"><p>${label}</p>
      ${items.map(([href, text, glyph, tone]) => `<a class="rail-link" href="${href}"${current(href)}><span class="sticker sticker-${tone}">${icon(glyph)}</span><span>${text}</span></a>`).join("")}
    </div>`).join("")}
  </nav>
  <details class="rail-account">
    <summary>${avatar}<span><strong>${staff ? "Panel petugas" : "Gedung E"}</strong><small>${staff ? "Kelola laporan" : "Akses petugas"}</small></span>${icon("chevron-left")}</summary>
    <div class="rail-account-menu paper-card">
      <a href="/admin"${current("/admin")}>${icon("shield-check")} Panel petugas</a>
      ${themeToggle}
    </div>
  </details>
</aside>
<header class="dashboard-bar">
  <div class="mobile-masthead">
    ${brand}
    <a class="bar-search" href="/#daftar-barang" data-search-open aria-label="Cari barang">${icon("search")}</a>
  </div>
  <div class="bar-notice" data-bar-notice>
    <div class="dashboard-bar-inner">
      <span class="bar-badge"><span class="map-pulse" aria-hidden="true"></span><span>GEDUNG E</span></span>
      <span class="bar-location">Barang hilang &amp; ditemukan<span> · FISIP UI</span></span>
      <div class="bar-actions">
        <a class="bar-guide" href="/alur">Panduan ${icon("chevron-left")}</a>
        ${staff ? link("/admin", "Panel petugas", "primary", "arrow-right") : link("/laporkan", "Lapor barang", "primary", "arrow-right")}
        <button type="button" class="bar-dismiss" data-bar-dismiss aria-label="Sembunyikan pemberitahuan" hidden>${icon("x-lg")}</button>
      </div>
    </div>
  </div>
</header>
<main class="page-width main-content${active === "/" || active === "/alur" ? " dashboard-main" : ""}" id="main-content">${main}</main>
<footer class="site-footer page-width"><div class="footer-line">
  <span>Barang Hilang &amp; Ditemukan · Gedung E FISIP UI</span>
  <div class="footer-links"><a href="/privasi">Privasi dan ketentuan</a><a href="/admin">Panel petugas</a>${themeToggle}</div>
</div></footer>
<nav class="dashboard-dock" id="mobile-navigation" aria-label="Navigasi utama ponsel">
  ${dockItems.map(([href, text, glyph]) => {
    const report = href === "/laporkan";
    const mark = report ? '<span class="dock-report-icon" aria-hidden="true"></span>' : glyph ? icon(glyph) : avatar;
    return `<a class="dock-link${report ? " dock-report" : ""}" href="${href}"${current(href)}>${mark}<span>${text}</span></a>`;
  }).join("")}
</nav>
<dialog class="search-dialog paper-card" data-search-dialog aria-labelledby="search-dialog-title">
  <div class="search-dialog-title"><h2 id="search-dialog-title">Cari barang</h2>
    <form method="dialog"><button class="tour-close" aria-label="Tutup pencarian">${icon("x-lg")}</button></form>
  </div>
  <form class="search-with-button" action="/#daftar-barang" method="get">
    <label class="search-field">${icon("search")}<input name="q" type="search" maxlength="80" placeholder="Nama barang atau lokasi" aria-label="Nama barang atau lokasi" autofocus></label>
    ${submit("Cari")}
  </form>
</dialog>
</body></html>`;
}

export function journeyPage() {
  return layout("Alur pengembalian", journeyContent(), "/alur");
}

function notice(message: string) {
  return `<p class="notice notice-success" role="status">${icon("check2-circle")}${esc(message)}</p>`;
}

function empty(title: string, message: string, action = "") {
  return `<div class="empty-search">${icon("inbox")}<h3>${esc(title)}</h3><p>${esc(message)}</p>${action}</div>`;
}

function status(label: string, color: string) {
  return `<span class="status-pill status-${color}">${esc(label)}</span>`;
}

const timeFormat = new Intl.DateTimeFormat("id-ID", {
  dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Jakarta",
});

function localTime(seconds: number) {
  const date = new Date(seconds * 1000);
  return `<time datetime="${date.toISOString()}">${esc(timeFormat.format(date))} WIB</time>`;
}

function categoryOptions(selected = "") {
  return categories.map(category => `<option${category === selected ? " selected" : ""}>${esc(category)}</option>`).join("");
}

function thumbnail(path: string | null) {
  return path
    ? `<img class="item-thumb" src="${esc(path)}" alt="" width="64" height="64" loading="lazy">`
    : `<span class="item-thumb item-placeholder">${icon("box-seam")}</span>`;
}

function row(item: { id: string; title: string; category: string; location: string }, state: string, color: string, image: string | null, href: string, action: string) {
  return `<article class="item-row">
    <div class="item-primary">${thumbnail(image)}<div class="item-name"><h3>${esc(item.title)}</h3><p>${esc(item.category)}</p></div></div>
    <div class="item-location">${icon("geo-alt")}<span>${esc(item.location)}</span></div>
    <div class="item-status">${status(state, color)}</div>
    <a class="item-action" href="${esc(href)}" aria-label="${esc(action + " " + item.title)}"><span>${esc(action)}</span>${icon("arrow-right")}</a>
  </article>`;
}

function list(rows: string) {
  return `<div class="item-list" data-item-list data-view="list">
    <div class="list-columns" aria-hidden="true"><span>Barang</span><span>Lokasi</span><span>Status</span><span></span></div>
    ${rows}
  </div>`;
}

function listHeading(title: string, count: number, toggle = false) {
  return `<div class="section-heading"><div><h2>${esc(title)}</h2><p>${count} barang ditampilkan</p></div>${toggle ? `
  <div class="view-options" role="group" aria-label="Tampilan daftar">
    <button type="button" data-view-option="list" aria-pressed="true">${icon("list-ul")}Daftar</button>
    <button type="button" data-view-option="grid" aria-pressed="false">${icon("grid")}Kartu</button>
  </div>` : ""}</div>`;
}

function query(path: string, values: Record<string, string | number>) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) if (value) params.set(key, String(value));
  const suffix = params.toString();
  return suffix ? `${path}?${suffix}` : path;
}

function pager(page: number, more: boolean, path: string, params: Record<string, string>) {
  if (page === 1 && !more) return "";
  return `<nav class="actions pagination-links" aria-label="Halaman hasil">
    ${page > 1 ? link(query(path, { ...params, halaman: page - 1 }), "Sebelumnya") : ""}
    ${more ? link(query(path, { ...params, halaman: page + 1 }), "Berikutnya") : ""}
  </nav>`;
}

function summary(label: string, count: number | null, detail: string, href: string, glyph: string, tone: string) {
  return `<a class="summary-card" href="${esc(href)}"><span class="summary-icon summary-${tone}">${icon(glyph)}</span><span><span class="summary-value">${count === null ? esc(label) : count}</span><span class="summary-label">${esc(count === null ? detail : label)}</span></span><span class="summary-arrow">${icon("arrow-up-right")}</span></a>`;
}

export function homePage(items: PublicReport[], counts: HomeSummary, filters: { q: string; kind: string; category: string }, page: number, more: boolean) {
  const filtersActive = Boolean(filters.q || filters.kind || filters.category);
  const rows = items.map(item => row(
    item, item.ready ? "Siap diambil" : item.kind === "found" ? "Ditemukan" : "Hilang",
    item.ready ? "published" : item.kind, item.has_photo ? `/foto/barang/${item.id}` : null,
    `/barang/${item.id}`, "Detail"
  )).join("");
  const filtersHtml = `<form class="list-controls" action="/#daftar-barang" method="get" data-tour-target="daftar">
    <div class="search-with-button"><div class="search-field">${icon("search")}
      <input name="q" type="search" value="${esc(filters.q)}" maxlength="80" placeholder="Cari barang atau lokasi" aria-label="Cari barang">
    </div>${submit("Cari")}</div>
    <div class="filter-row">
      <div class="type-filters" aria-label="Filter status">
        ${[["", "Semua"], ["found", "Ditemukan"], ["lost", "Hilang"]].map(([kind, name]) =>
          `<a class="filter-chip" aria-current="${kind === filters.kind ? "true" : "false"}" href="${esc(query("/", { ...filters, kind }))}#daftar-barang">${name}</a>`
        ).join("")}
      </div>
      <input type="hidden" name="kind" value="${esc(filters.kind)}">
      <select class="filter-select" name="category" aria-label="Filter kategori" data-submit-change>
        <option value="">Semua kategori</option>${categoryOptions(filters.category)}
      </select>
    </div>
  </form>`;
  return layout("Barang hilang & ditemukan", `
    ${dashboardIntro(counts)}
    <section class="surface list-panel" id="daftar-barang">${listHeading("Daftar barang", items.length, Boolean(rows))}
      ${filtersHtml}
      ${rows ? list(rows) : empty(
        filtersActive ? "Barang tidak ditemukan" : "Belum ada laporan yang ditayangkan",
        filtersActive ? "Coba kata kunci atau kategori lain." : "Laporan akan muncul setelah petugas Gedung E meninjaunya.",
        filtersActive ? link("/#daftar-barang", "Reset filter") : link("/laporkan", "Laporkan barang")
      )}
      ${pager(page, more, "/", filters)}
    </section>
    ${dashboardTour()}`, "/");
}

function textInput(name: string, label: string, max: number, placeholder = "", required = true, type = "text", id = name) {
  return `<label class="form-label" for="${id}">${esc(label)}</label>
    <input class="form-control" id="${id}" name="${name}" type="${type}" maxlength="${max}" placeholder="${esc(placeholder)}"${required ? " required" : ""}>`;
}

function textarea(name: string, label: string, max: number, placeholder: string) {
  return `<label class="form-label" for="${name}">${esc(label)}</label>
    <textarea class="form-control" id="${name}" name="${name}" rows="4" maxlength="${max}" placeholder="${esc(placeholder)}" required></textarea>`;
}

function checkbox(name: string, label: string, required = false) {
  return `<label class="checkbox-row"><input type="checkbox" name="${name}" value="1"${required ? " required" : ""}><span>${esc(label)}</span></label>`;
}

function photoField(label: string, name = "photo") {
  return `<label class="form-label" for="${name}">${esc(label)}</label>
    <input class="form-control" id="${name}" name="${name}" type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif" data-photo>
    <p class="field-help" data-photo-error role="alert" hidden></p>`;
}

function requestKey() {
  return `<input type="hidden" name="request_key" value="${crypto.randomUUID()}">`;
}

export function reportPage() {
  const form = `<form class="flow-form row g-3" method="post" action="/laporkan" enctype="multipart/form-data" data-image-form>
    ${requestKey()}
    <div class="col-md-6"><label class="form-label" for="kind">Jenis laporan</label>
      <select class="form-select" id="kind" name="kind" required><option value="found">Barang ditemukan</option><option value="lost">Barang hilang</option></select></div>
    <div class="col-md-6"><label class="form-label" for="category">Kategori</label>
      <select class="form-select" id="category" name="category" required>${categoryOptions()}</select></div>
    <div class="col-md-6">${textInput("title", "Nama barang", 100, "Misalnya, dompet hitam")}</div>
    <div class="col-md-6">${textInput("location", "Lokasi di Gedung E", 120, "Misalnya, lobi lantai 1")}</div>
    <div class="col-12">${textarea("description", "Deskripsi barang", 800, "Jelaskan ciri umum dan kapan barang hilang atau ditemukan.")}</div>
    <div class="col-md-6">${textInput("reporter_name", "Nama pelapor", 100)}</div>
    <div class="col-md-6">${textInput("reporter_contact", "Kontak pelapor (opsional)", 120, "Email atau nomor telepon", false)}</div>
    <div class="col-12">${photoField("Foto barang (opsional)")}<p class="form-text">Foto sebaiknya hanya memperlihatkan barang. Hindari wajah, kartu identitas, dan dokumen pribadi.</p></div>
    <div class="col-12">${checkbox("ack", "Saya memahami bahwa rincian dan foto yang disetujui petugas dapat ditampilkan ke publik.", true)}</div>
    <div class="col-12 form-actions">${submit("Kirim laporan", "arrow-right")}</div>
  </form>`;
  return layout("Laporkan barang", `${heading("Laporkan barang", "Isi laporan barang hilang atau temuan di Gedung E FISIP UI.", "/")}
    <div class="form-layout">${panel("Rincian laporan", form)}
      <aside class="surface help-panel"><span class="summary-icon summary-returned">${icon("info-circle")}</span>
      <h2>Jika menemukan barang</h2><p>Titipkan barang kepada petugas Gedung E. Petugas memeriksa laporan sebelum menayangkannya.</p>
      <p>Nama dan kontak pelapor digunakan oleh petugas untuk menindaklanjuti laporan.</p></aside>
    </div>`, "/laporkan");
}

export function reportSentPage() {
  return layout("Laporan diterima", `${heading("Laporan diterima")}
    ${panel("Menunggu tinjauan", `${notice("Laporan Anda tersimpan.")}<p>Petugas Gedung E akan memeriksa laporan sebelum menayangkannya.</p>${link("/", "Kembali ke beranda", "primary", "arrow-right")}`)}`, "/laporkan");
}

export function reportDetail(item: PublicReport) {
  const action = item.kind === "found" && !item.ready ? link(`/klaim/${item.id}`, "Ajukan klaim", "primary", "shield-check") : "";
  const image = item.has_photo
    ? `<img src="/foto/barang/${esc(item.id)}" alt="${esc("Foto " + item.title)}">`
    : `<span class="detail-placeholder">${icon("box-seam")}Foto belum tersedia</span>`;
  return layout(item.title, `${heading(item.title, "", "/")}
    <article class="surface detail-card"><div class="detail-image">${image}</div><div class="detail-content">
      ${status(item.ready ? "Siap diambil" : item.kind === "found" ? "Ditemukan" : "Hilang", item.ready ? "published" : item.kind)}
      <h2>Rincian barang</h2><dl class="detail-meta"><div><dt>Kategori</dt><dd>${esc(item.category)}</dd></div><div><dt>Lokasi di Gedung E</dt><dd>${esc(item.location)}</dd></div></dl>
      <p class="text-preserve">${esc(item.description)}</p>
      <p class="field-help">Ditayangkan ${localTime(item.published_at)}</p>
      ${item.ready ? `<p>Petugas sedang menunggu pengambilan oleh pengaju yang sudah diverifikasi.</p>` : ""}
      <div class="actions">${action}</div>
    </div></article>`, "/");
}

export function claimPage(item: PublicReport) {
  const form = `<form class="flow-form" method="post" action="/klaim/${esc(item.id)}">
    ${requestKey()}
    <div class="field-gap">${textInput("claimant_name", "Nama pengaju", 100)}</div>
    <div class="field-gap">${textarea("proof", "Ciri khusus atau bukti kepemilikan", 1000, "Misalnya, isi dompet atau tanda khusus yang hanya diketahui pemilik.")}</div>
    <div class="form-actions">${submit("Kirim pengajuan", "arrow-right")}</div></form>`;
  return layout("Ajukan klaim", `${heading("Ajukan klaim", "Bantu petugas memverifikasi bahwa barang ini milik Anda.", `/barang/${item.id}`, "Detail barang")}
    <div class="form-layout">${panel("Bukti kepemilikan", form)}<aside class="surface help-panel">
    <div class="claim-item">${thumbnail(item.has_photo ? `/foto/barang/${item.id}` : null)}<div><h2>${esc(item.title)}</h2><p>${esc(item.location)}</p></div></div>
    <p>Hindari menuliskan PIN atau kata sandi. Bukti kepemilikan hanya ditampilkan kepada petugas.</p></aside></div>`, "/cek-klaim");
}

const claimStates: Record<ClaimState, [string, string]> = {
  submitted: ["Menunggu verifikasi", "review"], ready: ["Siap diambil", "published"],
  returned: ["Sudah diserahkan", "returned"], rejected: ["Tidak disetujui", "lost"],
};

export function trackingPage(result?: TrackedClaim, code?: string, error = "") {
  const current = result && claimStates[result.state];
  const stages = ["Diajukan", "Siap diambil", "Diserahkan"];
  const step = result?.state === "returned" ? 2 : result?.state === "ready" ? 1 : 0;
  const progress = result?.state === "rejected" ? "" : `<ol class="progress-steps" aria-label="Perkembangan klaim">
    ${stages.map((name, index) => `<li class="${index < step ? "complete" : index === step ? "current" : ""}"${index === step ? ' aria-current="step"' : ""}>
      <span class="step-marker">${index < step ? icon("check2") : index + 1}</span>${name}</li>`).join("")}</ol>`;
  const copy = code ? `<div class="tracking-code"><div><span>Kode pelacakan</span><code data-code-text>${esc(code)}</code></div>
    <button class="button button-secondary" type="button" data-copy-code>${icon("clipboard")}<span>Salin kode</span></button></div><p class="field-help" data-copy-status aria-live="polite"></p>` : "";
  const details = result && current ? `<section class="surface result-panel">${status(current[0], current[1])}
    <h2>${esc(result.title)}</h2>
    <p class="text-preserve">${esc(code ? "Simpan kode ini untuk mengecek status klaim." :
    result.state === "ready" ? result.pickup || "Hubungi petugas Gedung E untuk mengambil barang." :
    result.state === "returned" ? "Petugas telah mencatat serah terima barang." :
    result.state === "rejected" ? "Klaim ini tidak disetujui oleh petugas." : "Petugas sedang memeriksa pengajuan Anda.")}</p>
    ${copy}${progress}</section>` : "";
  const form = `<form class="flow-form" method="post" action="/cek-klaim">
    <label class="form-label" for="code">Kode pelacakan</label>
    <input class="form-control tracking-input" id="code" name="code" type="text" maxlength="50" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Masukkan kode pelacakan" required>
    ${error ? `<p class="field-help tracking-error" role="alert">${esc(error)}</p>` : ""}
    <div class="form-actions">${submit("Cek status", "search")}</div></form>`;
  return layout("Cek status klaim", `${heading("Cek status klaim", "Masukkan kode yang Anda terima setelah mengajukan klaim.")}
    <div class="tracking-layout">${details}${panel("Cari klaim", form)}</div>`, "/cek-klaim");
}

export function historyPage(entries: HistoryEntry[], page: number, more: boolean) {
  const rows = entries.map(entry => `<article class="surface history-card">
    <figure class="history-photo">${entry.has_photo
      ? `<img src="/foto/serah-terima/${esc(entry.id)}" alt="Foto serah terima yang telah diburamkan" loading="lazy" width="208"><figcaption>${icon("shield-check")} Foto buram</figcaption>`
      : `<p>${icon("camera")} Serah terima tanpa foto</p>`}</figure>
    <div class="history-body">${status("Sudah diserahkan", "returned")}<h2>${esc(entry.title)}</h2><p>${esc(entry.category)} · Gedung E</p>
      <p class="history-time">${icon("clock-history")} ${localTime(entry.handed_over_at)}</p></div></article>`).join("");
  return layout("Histori serah terima", `${heading("Histori serah terima", "Catatan barang yang sudah diserahkan kepada pemilik.")}
    ${rows ? `<div class="history-list">${rows}</div>` : `<section class="surface">${empty("Belum ada serah terima", "Catatan muncul setelah petugas menyerahkan barang kepada pemilik.")}</section>`}
    ${pager(page, more, "/histori", {})}`, "/histori");
}

function passwordField(id: string, label: string, autocomplete: "current-password" | "new-password", proof = "") {
  const attributes = proof ? `data-password-proof="${proof}"` : "data-password-confirm";
  return `<div><label class="form-label" for="${id}">${esc(label)}</label>
    <input class="form-control" id="${id}" type="password" autocomplete="${autocomplete}"
      maxlength="128" ${attributes} required></div>`;
}

function passwordForm(action: string, salt: string, content: string, button: string, error = "") {
  return `<form class="flow-form" method="post" action="${action}" data-password-form data-salt="${esc(salt)}">
    <input class="visually-hidden" aria-hidden="true" tabindex="-1" type="text" name="username" value="petugas" autocomplete="username" readonly>
    ${content}
    <p class="field-help tracking-error" data-password-message role="alert" ${error ? "" : "hidden"}>${esc(error)}</p>
    <noscript><p class="field-help">Aktifkan JavaScript di browser untuk memproses sandi.</p></noscript>
    <div class="form-actions">${submit(button, "shield-check")}</div>
  </form>`;
}

const newPasswordFields = `${passwordField("new-password", "Sandi baru", "new-password", "new_proof")}
  ${passwordField("confirm-password", "Ulangi sandi baru", "new-password")}
  <p class="field-help">Anda bisa menyimpan sandinya di pengelola sandi browser.</p>`;

export function loginPage(salt: string, error = "") {
  const form = passwordForm("/admin/masuk", salt, passwordField("staff-password", "Sandi petugas", "current-password", "current_proof"), "Masuk", error);
  return layout("Panel petugas", `${heading("Panel petugas", "Kelola laporan, verifikasi klaim, dan catat serah terima.")}
    <div class="single-panel">${panel("Masuk sebagai petugas", `${form}
      <p class="form-actions"><a href="/admin/aktivasi">Aktivasi akun atau atur ulang sandi</a></p>`)}</div>`, "/admin");
}

export function activationPage(salt: string, error = "") {
  const code = `<div><label class="form-label" for="activation">Kode aktivasi</label>
    <input class="form-control" id="activation" name="activation" type="password" autocomplete="off"
      spellcheck="false" autocapitalize="off" maxlength="160" required></div>`;
  return layout("Aktivasi panel petugas", `${heading("Aktivasi panel petugas", "Gunakan kode sekali pakai untuk membuat sandi petugas.", "/admin", "Panel petugas")}
    <div class="single-panel">${panel("Buat sandi petugas", passwordForm("/admin/aktivasi", salt, code + newPasswordFields, "Aktifkan dan masuk", error))}</div>`, "/admin");
}

export function passwordPage(salt: string, error = "") {
  const current = passwordField("current-password", "Sandi saat ini", "current-password", "current_proof");
  return layout("Ubah sandi petugas", `${heading("Ubah sandi petugas", "Sesi pada perangkat lain akan berakhir setelah sandi diganti.", "/admin", "Panel petugas")}
    <div class="single-panel">${panel("Sandi petugas", passwordForm("/admin/sandi", salt, current + newPasswordFields, "Simpan sandi", error))}</div>`, "/admin", true);
}

function staffStatus(item: StaffReport): [string, string] {
  if (item.active_claim === "returned") return ["Sudah diserahkan", "returned"];
  if (item.active_claim === "ready") return ["Siap diambil", "published"];
  if (item.state === "pending") return ["Perlu tinjauan", "review"];
  if (item.state === "archived") return ["Diarsipkan", "lost"];
  if (item.pending_claims) return [`${item.pending_claims} klaim masuk`, "published"];
  return ["Tayang", "published"];
}

export function staffPage(items: StaffReport[], counts: { pending: number; active: number; returned: number }, filter: string, page: number, more: boolean) {
  const rows = items.map(item => {
    const [label, color] = staffStatus(item);
    return row(item, label, color, item.photo_key ? `/admin/foto/${item.id}` : null, `/admin/laporan/${item.id}`, "Kelola");
  }).join("");
  const filters = [
    ["", "Semua"], ["pending", "Perlu tinjauan"], ["active", "Tayang"], ["claims", "Ada klaim"], ["returned", "Diserahkan"], ["archived", "Arsip"],
  ];
  return layout("Panel petugas", `${heading("Panel petugas", "Tinjau laporan dan verifikasi pengajuan klaim.")}
    <div class="form-actions">
      ${link("/admin/sandi", "Ubah sandi", "secondary", "shield-check")}
      <form method="post" action="/admin/keluar">${submit("Keluar", "", "secondary")}</form>
    </div>
    <div class="summary-grid" aria-label="Ringkasan panel">
      ${summary("Perlu tinjauan", counts.pending, "", "/admin?status=pending", "file-earmark-text", "lost")}
      ${summary("Laporan tayang", counts.active, "", "/admin?status=active", "inbox", "returned")}
      ${summary("Sudah diserahkan", counts.returned, "", "/admin?status=returned", "check2-circle", "found")}
    </div>
    <section class="surface list-panel">${listHeading("Kelola laporan", items.length)}
      <div class="list-controls"><div class="type-filters">${filters.map(([key, label]) => `<a class="filter-chip" href="${esc(query("/admin", { status: key }))}" aria-current="${key === filter ? "true" : "false"}">${label}</a>`).join("")}</div></div>
      ${rows ? list(rows) : empty("Belum ada laporan", "Laporan yang sesuai akan tampil di sini.")}
      ${pager(page, more, "/admin", { status: filter })}
    </section>`, "/admin", true);
}

function claimActions(report: StaffReport, claim: Claim) {
  const action = `/admin/laporan/${esc(report.id)}/klaim/${esc(claim.id)}`;
  if (claim.state === "submitted" && !report.active_claim && report.state === "published") {
    return `<form class="flow-form" method="post" action="${action}/setujui">
      ${textInput("pickup", "Petunjuk pengambilan", 240, "Contoh: pos petugas Gedung E, Senin pukul 10.00–14.00 WIB", true, "text", `pickup-${esc(claim.id)}`)}
      ${checkbox("verified", "Saya sudah memeriksa bukti kepemilikan dan barang ada pada petugas.", true)}
      <div class="form-actions">${submit("Setujui klaim", "check2")}</div>
    </form><form class="form-actions" method="post" action="${action}/tolak">${submit("Tolak klaim", "", "secondary")}</form>`;
  }
  if (claim.state === "ready") {
    return `<form class="flow-form" method="post" action="${action}/serahkan" enctype="multipart/form-data" data-image-form>
      ${checkbox("confirmed", "Saya sudah memeriksa pemilik dan menyerahkan barangnya.", true)}
      ${photoField("Foto serah terima (opsional)", "handover_photo")}
      <p class="form-text">Foto publik diburamkan. Ambil gambar barang dan tangan saja, tanpa wajah atau dokumen.</p>
      ${checkbox("photo_consent", "Penerima menyetujui publikasi foto versi buram.")}
      <div class="form-actions">${submit("Catat serah terima", "check2-circle")}</div>
    </form><form class="form-actions" method="post" action="${action}/tolak">${submit("Batalkan persetujuan", "", "secondary")}</form>`;
  }
  return "";
}

export function staffDetail(report: StaffReport, claims: Claim[], message = "") {
  const [label, color] = staffStatus(report);
  const base = `/admin/laporan/${esc(report.id)}`;
  const publish = report.state === "pending" ? `<form class="flow-form" method="post" action="${base}/tayangkan">
    ${checkbox("scope", "Kejadian berlangsung di Gedung E dan rincian layak ditampilkan.", true)}
    ${report.kind === "found" ? checkbox("received", "Barang sudah diterima petugas Gedung E.", true) : ""}
    <div class="form-actions">${submit("Tayangkan laporan", "check2")}</div></form>` : "";
  const archive = report.state !== "archived" && !report.active_claim ? `<form class="form-actions" method="post" action="${base}/arsipkan">${submit("Arsipkan laporan", "", "secondary")}</form>` : "";
  const details = `<article class="surface admin-record"><div class="record-body"><h2>Rincian laporan</h2>
    ${status(label, color)}<p class="record-meta">${esc(report.category)} · ${esc(report.location)}</p>
    <p class="text-preserve">${esc(report.description)}</p>
    ${report.photo_key ? `<img class="staff-photo" src="/admin/foto/${esc(report.id)}" alt="Foto barang yang dikirim pelapor">` : ""}
    <dl class="detail-meta"><div><dt>Pelapor</dt><dd>${esc(report.reporter_name)}</dd></div>
    <div><dt>Kontak</dt><dd>${esc(report.reporter_contact || "Tidak diisi")}</dd></div></dl>
    <p class="field-help">${localTime(report.created_at)}</p>${publish}${archive}
  </div></article>`;
  const claimCards = claims.map(claim => {
    const [label, color] = claimStates[claim.state];
    return `<article class="surface admin-record"><div class="record-body">
      <h2 class="record-heading">${esc(claim.claimant_name)} ${status(label, color)}</h2>
      <p class="text-preserve">${esc(claim.proof)}</p>
      ${claim.pickup ? `<p class="text-preserve">${esc(claim.pickup)}</p>` : ""}
      ${claim.handed_over_at ? `<p class="field-help">${localTime(claim.handed_over_at)}</p>` : ""}
      ${claimActions(report, claim)}
    </div></article>`;
  }).join("");
  return layout(report.title, `${heading(report.title, "Pengelolaan laporan dan klaim", "/admin", "Panel petugas")}
    ${message ? notice(message) : ""}
    <div class="record-grid record-grid-columns">${details}<div class="record-grid">
      ${claimCards || panel("Pengajuan klaim", "<p>Belum ada pengajuan pada laporan ini.</p>")}
    </div></div>`, "/admin", true);
}

export function errorPage(title: string, message: string, back = "/") {
  return layout(title, `${heading(title)}${panel("Informasi", `<p>${esc(message)}</p>${link(back, "Kembali", "secondary", "chevron-left")}`)}`);
}

export function privacyPage() {
  return layout("Privasi dan ketentuan", `${heading("Privasi dan ketentuan", "Layanan barang hilang dan ditemukan untuk Gedung E FISIP UI.", "/")}
    <section class="surface prose-panel">
      <h2>Laporan dan klaim</h2>
      <p>Nama, kontak pelapor, nama pengaju, dan bukti kepemilikan digunakan petugas untuk meninjau laporan dan klaim. Judul, lokasi temuan, deskripsi, dan foto barang dapat tampil setelah diperiksa petugas. Hindari mencantumkan data identitas atau informasi sensitif pada bagian tersebut.</p>
      <h2>Foto serah terima</h2>
      <p>Histori menampilkan barang dan waktu serah terima. Foto versi buram dapat ditampilkan jika penerima menyetujuinya.</p>
      <h2>Panel petugas</h2>
      <p>Panel dilindungi sandi petugas dan menggunakan cookie sesi setelah masuk. Pengunjung dapat membuka daftar barang, melapor, dan mengajukan klaim langsung.</p>
    </section>`);
}

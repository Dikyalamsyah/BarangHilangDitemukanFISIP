export const categories = ["Gawai", "Earphone", "Botol/Tupperware", "Kartu/ID", "Tas/Dompet", "Lainnya"] as const;

export type ReportKind = "found" | "lost";
export type ReportState = "pending" | "published" | "archived";
export type ClaimState = "submitted" | "ready" | "rejected" | "returned";

export type PublicReport = {
  id: string;
  kind: ReportKind;
  title: string;
  category: string;
  location: string;
  description: string;
  has_photo: number;
  published_at: number;
  ready: number;
};

export type StaffReport = {
  id: string;
  kind: ReportKind;
  title: string;
  category: string;
  location: string;
  description: string;
  reporter_name: string;
  reporter_contact: string | null;
  photo_key: string | null;
  state: ReportState;
  created_at: number;
  active_claim: "ready" | "returned" | null;
  pending_claims: number;
};

export type Claim = {
  id: string;
  report_id: string;
  claimant_name: string;
  proof: string;
  state: ClaimState;
  pickup: string | null;
  photo_key: string | null;
  created_at: number;
  handed_over_at: number | null;
};

export type TrackedClaim = {
  title: string;
  state: ClaimState;
  pickup: string | null;
};

export type HistoryEntry = {
  id: string;
  title: string;
  category: string;
  handed_over_at: number;
  has_photo: number;
};

export type HomeSummary = {
  found: number;
  lost: number;
  recent: { date: string; count: number }[];
};

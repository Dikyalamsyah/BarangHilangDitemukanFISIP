import type { Env } from "../index";
import { digest, html, keyedHash, rateLimit, readForm, redirect, RequestError } from "./http";
import { activationPage, loginPage, passwordPage } from "./views";

const SESSION_COOKIE = "__Host-gedung-e-staff";
const SESSION_AGE = 8 * 60 * 60;
const HEX_KEY = /^[a-f0-9]{64}$/;
const NO_KEY = "0".repeat(64);

type Account = { password_digest: string; revision: string; activation_fingerprint: string };

function sameHash(left: string, right: string) {
  const encode = new TextEncoder();
  const subtle = crypto.subtle as SubtleCrypto & {
    timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean;
  };
  return subtle.timingSafeEqual(encode.encode(left), encode.encode(right));
}

function accountRecord(db: D1Database) {
  return db.prepare("SELECT password_digest, revision, activation_fingerprint FROM staff_account WHERE id=1").first<Account>();
}

function sessionToken(request: Request) {
  const entry = request.headers.get("Cookie")?.split(";").map(value => value.trim())
    .find(value => value.startsWith(SESSION_COOKIE + "="));
  const token = entry?.slice(SESSION_COOKIE.length + 1);
  return token && HEX_KEY.test(token) ? token : null;
}

function cookie(token: string, age: number) {
  return `${SESSION_COOKIE}=${token}; Path=/; Max-Age=${age}; Secure; HttpOnly; SameSite=Lax`;
}

async function openSession(db: D1Database, revision: string) {
  const token = Array.from(crypto.getRandomValues(new Uint8Array(32)), byte => byte.toString(16).padStart(2, "0")).join("");
  const results = await db.batch([
    db.prepare(`INSERT INTO staff_sessions(token_hash,account_revision,expires_at)
      SELECT ?,revision,unixepoch()+? FROM staff_account WHERE id=1 AND revision=?`)
      .bind(await digest(token), SESSION_AGE, revision),
    db.prepare(`DELETE FROM staff_sessions WHERE expires_at<=unixepoch()
      OR account_revision<>(SELECT revision FROM staff_account WHERE id=1)`),
  ]);
  if (!results[0].meta.changes) throw new RequestError(409, "Sandi baru saja diperbarui. Silakan masuk kembali.", "/admin");
  return redirect("/admin", cookie(token, SESSION_AGE));
}

async function isSignedIn(db: D1Database, token: string | null) {
  return !!token && !!await db.prepare(`SELECT 1 FROM staff_sessions s JOIN staff_account a
    ON a.id=1 AND a.revision=s.account_revision WHERE s.token_hash=? AND s.expires_at>unixepoch()`)
    .bind(await digest(token)).first();
}

function passwordProof(form: FormData, field: string, back: string) {
  const proof = form.get(field);
  if (typeof proof !== "string" || !HEX_KEY.test(proof)) {
    throw new RequestError(400, "Formulir sandi belum siap. Buka kembali halaman dan aktifkan JavaScript.", back);
  }
  return proof;
}

// Safari does the work of deriving the password key. The Worker stores only a
// separate HMAC with a server-side secret, keeping login within the free CPU limit.
function passwordDigest(env: Env, proof: string) {
  return keyedHash(env.GEDUNG_E_APP_KEY, "staff password v1:" + proof);
}

async function activate(request: Request, db: D1Database, env: Env, salt: string, get: boolean) {
  const back = "/admin/aktivasi";
  if (get) return html(activationPage(salt));
  await rateLimit(request, db, env.GEDUNG_E_APP_KEY, "staff-activation", 8, 900, back);
  const form = await readForm(request, back, 4096);
  const raw = form.get("activation");
  if (typeof raw !== "string" || raw.length > 160) {
    return html(activationPage(salt, "Periksa kembali kode aktivasi Anda."), 400);
  }

  const fingerprint = await digest(raw.trim());
  const [initialHash = NO_KEY, expires = "0"] = (env.GEDUNG_E_ADMIN_SETUP || "").split(":");
  const account = await accountRecord(db);
  const initial = HEX_KEY.test(initialHash) && sameHash(fingerprint, initialHash) &&
    Number(expires) > Date.now() / 1000 && !account;
  const recoveryCode = env.GEDUNG_E_ADMIN_RECOVERY?.trim();
  const recoveryHash = recoveryCode && recoveryCode.length >= 24 ? await digest(recoveryCode) : NO_KEY;
  const recovery = recoveryHash !== NO_KEY && sameHash(fingerprint, recoveryHash) &&
    !sameHash(fingerprint, account?.activation_fingerprint || NO_KEY);
  if (!initial && !recovery) {
    return html(activationPage(salt, "Kode aktivasi tidak berlaku, sudah dipakai, atau sudah kedaluwarsa."), 403);
  }

  const hash = await passwordDigest(env, passwordProof(form, "new_proof", back));
  const revision = crypto.randomUUID();
  const result = account
    ? await db.prepare("UPDATE staff_account SET password_digest=?,revision=?,activation_fingerprint=? WHERE id=1 AND revision=?")
      .bind(hash, revision, fingerprint, account.revision).run()
    : await db.prepare("INSERT INTO staff_account(id,password_digest,revision,activation_fingerprint) VALUES(1,?,?,?) ON CONFLICT(id) DO NOTHING")
      .bind(hash, revision, fingerprint).run();
  if (!result.meta.changes) throw new RequestError(409, "Aktivasi sudah dilakukan. Silakan masuk ke panel.", "/admin");
  return openSession(db, revision);
}

async function changePassword(request: Request, db: D1Database, env: Env, salt: string, get: boolean) {
  const back = "/admin/sandi";
  if (get) return html(passwordPage(salt));
  await rateLimit(request, db, env.GEDUNG_E_APP_KEY, "staff-password", 10, 900, back);
  const form = await readForm(request, back, 4096);
  const account = await accountRecord(db);
  const current = await passwordDigest(env, passwordProof(form, "current_proof", back));
  if (!account || !sameHash(current, account.password_digest)) {
    return html(passwordPage(salt, "Sandi saat ini tidak cocok."), 401);
  }

  const hash = await passwordDigest(env, passwordProof(form, "new_proof", back));
  const revision = crypto.randomUUID();
  const result = await db.prepare("UPDATE staff_account SET password_digest=?,revision=? WHERE id=1 AND revision=?")
    .bind(hash, revision, account.revision).run();
  if (!result.meta.changes) throw new RequestError(409, "Sandi baru saja diperbarui. Silakan masuk kembali.", "/admin");
  return openSession(db, revision);
}

export async function authorizeAdmin(request: Request, db: D1Database, env: Env, path: string, get: boolean) {
  const salt = env.GEDUNG_E_KDF_SALT;
  if (!salt || !/^[a-f0-9]{32}$/.test(salt)) throw new RequestError(503, "Akses petugas sedang disiapkan.");
  if (path === "/admin/aktivasi") return activate(request, db, env, salt, get);

  if (path === "/admin/masuk" && !get) {
    await rateLimit(request, db, env.GEDUNG_E_APP_KEY, "staff-login", 10, 900, "/admin");
    const form = await readForm(request, "/admin", 4096);
    const current = await passwordDigest(env, passwordProof(form, "current_proof", "/admin"));
    const account = await accountRecord(db);
    if (!sameHash(current, account?.password_digest || NO_KEY) || !account) {
      return html(loginPage(salt, "Sandi tidak cocok. Periksa kembali sandi Anda."), 401);
    }
    return openSession(db, account.revision);
  }

  const token = sessionToken(request);
  if (path === "/admin/keluar" && !get) {
    if (token) await db.prepare("DELETE FROM staff_sessions WHERE token_hash=?").bind(await digest(token)).run();
    return redirect("/admin", cookie("", 0));
  }
  if (!await isSignedIn(db, token)) return html(loginPage(salt), 401);
  if (path === "/admin/sandi") return changePassword(request, db, env, salt, get);
}

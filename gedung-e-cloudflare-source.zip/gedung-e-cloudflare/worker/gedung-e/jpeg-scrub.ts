// Keep the encoded picture and its JPEG tables, and drop every application
// segment, comment and trailing byte. In particular, EXIF and GPS stay out.
export function stripJpegMetadata(bytes: Uint8Array, maxSide: number): Uint8Array<ArrayBuffer> {
  const invalid = new Error("Invalid JPEG");
  if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) throw invalid;
  const output = new Uint8Array(bytes.length);
  output.set(bytes.subarray(0, 2));
  let offset = 2;
  let written = 2;
  let hasFrame = false;
  let hasScan = false;
  let scanning = false;

  while (offset < bytes.length) {
    if (scanning) {
      const start = offset;
      for (;;) {
        const next = bytes.indexOf(0xff, offset);
        if (next < 0) throw invalid;
        let code = next + 1;
        while (bytes[code] === 0xff) code++;
        const marker = bytes[code];
        if (marker === 0 || (marker >= 0xd0 && marker <= 0xd7)) {
          offset = code + 1;
          continue;
        }
        output.set(bytes.subarray(start, next), written);
        written += next - start;
        offset = next;
        scanning = false;
        break;
      }
    }

    if (bytes[offset++] !== 0xff) throw invalid;
    while (bytes[offset] === 0xff) offset++;
    const marker = bytes[offset++];
    if (marker === 0xd9) {
      if (!hasScan) throw invalid;
      output[written++] = 0xff;
      output[written++] = 0xd9;
      return output.subarray(0, written);
    }

    const length = bytes[offset] * 256 + bytes[offset + 1];
    if (!Number.isInteger(length) || length < 2 || offset + length > bytes.length) throw invalid;
    const frame = marker === 0xc0 || marker === 0xc1 || marker === 0xc2;
    if (frame) {
      const height = bytes[offset + 3] * 256 + bytes[offset + 4];
      const width = bytes[offset + 5] * 256 + bytes[offset + 6];
      const components = bytes[offset + 7];
      if (hasFrame || length !== 8 + 3 * components || bytes[offset + 2] !== 8 ||
          ![1, 3].includes(components) || !height || !width || Math.max(width, height) > maxSide) throw invalid;
      hasFrame = true;
    }
    if (marker === 0xda) {
      if (!hasFrame || length < 6) throw invalid;
      scanning = hasScan = true;
    }

    const metadata = (marker >= 0xe0 && marker <= 0xef) || marker === 0xfe;
    if (!metadata) {
      if (!frame && ![0xc4, 0xda, 0xdb, 0xdd].includes(marker)) throw invalid;
      output[written++] = 0xff;
      output[written++] = marker;
      output.set(bytes.subarray(offset, offset + length), written);
      written += length;
    }
    offset += length;
  }
  throw invalid;
}

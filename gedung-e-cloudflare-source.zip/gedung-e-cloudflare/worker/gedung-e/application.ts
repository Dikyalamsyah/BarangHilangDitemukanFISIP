import type { Env } from "../index";
import { authorizeAdmin } from "./admin-auth";
import { checkOrigin, digest, field, html, isId, keyedHash, nonce, rateLimit, readForm, redirect, RequestError } from "./http";
import { photoResponse, preparePhoto, writeWithPhoto } from "./photos";
import { categories, type Claim, type HistoryEntry, type HomeSummary, type PublicReport, type StaffReport, type TrackedClaim } from "./types";
import { claimPage, errorPage, historyPage, homePage, journeyPage, privacyPage, reportDetail, reportPage, reportSentPage, staffDetail, staffPage, trackingPage } from "./views";

const PAGE_SIZE = 24;
const publicCondition = `r.state='published' AND NOT EXISTS (
  SELECT 1 FROM claims AS returned WHERE returned.report_id=r.id AND returned.state='returned'
)`;
const publicSelect = `r.id, r.kind, r.title, r.category, r.location, r.description, r.published_at,
  (r.photo_key IS NOT NULL) AS has_photo,
  EXISTS(SELECT 1 FROM claims c WHERE c.report_id=r.id AND c.state='ready') AS ready`;
const staffSelect = `r.id, r.kind, r.title, r.category, r.location, r.description,
  r.reporter_name, r.reporter_contact, r.photo_key, r.state, r.created_at,
  (SELECT c.state FROM claims c WHERE c.report_id=r.id AND c.state IN ('ready','returned')) AS active_claim,
  (SELECT count(*) FROM claims c WHERE c.report_id=r.id AND c.state='submitted') AS pending_claims`;

function pageNumber(url: URL) {
  const value = url.searchParams.get("halaman");
  return value && /^\d{1,4}$/.test(value) ? Math.max(1, Math.min(1000, Number(value))) : 1;
}

function notFound(back = "/"): never {
  throw new RequestError(404, "Halaman atau barang ini tidak tersedia.", back);
}

function changes(result: D1Result) {
  return result.meta.changes > 0;
}

async function getPublicReport(db: D1Database, id: string) {
  return db.prepare(`SELECT ${publicSelect} FROM reports r WHERE r.id=? AND ${publicCondition}`)
    .bind(id).first<PublicReport>();
}

async function getStaffReport(db: D1Database, id: string) {
  return db.prepare(`SELECT ${staffSelect} FROM reports r WHERE r.id=?`).bind(id).first<StaffReport>();
}

async function browse(db: D1Database, url: URL) {
  const rawKind = url.searchParams.get("kind") || "";
  const rawCategory = url.searchParams.get("category") || "";
  const filters = {
    kind: ["found", "lost"].includes(rawKind) ? rawKind : "",
    category: categories.some(category => category === rawCategory) ? rawCategory : "",
    q: (url.searchParams.get("q") || "").trim().slice(0, 80),
  };
  const page = pageNumber(url);
  const secondsPerDay = 86_400;
  const jakartaOffset = 7 * 3600;
  const today = Math.floor((Date.now() / 1000 + jakartaOffset) / secondsPerDay);
  const firstDay = today - 6;
  const results = await db.batch([
    db.prepare(`SELECT ${publicSelect} FROM reports r WHERE ${publicCondition}
      AND (?='' OR r.kind=?) AND (?='' OR r.category=?)
      AND (?='' OR instr(lower(r.title || ' ' || r.location || ' ' || r.category),lower(?)) > 0)
      ORDER BY r.published_at DESC, r.id LIMIT ? OFFSET ?`)
      .bind(filters.kind, filters.kind, filters.category, filters.category, filters.q, filters.q, PAGE_SIZE + 1, (page - 1) * PAGE_SIZE),
    db.prepare(`SELECT r.kind, count(*) AS count FROM reports r WHERE ${publicCondition} GROUP BY r.kind`),
    db.prepare(`SELECT date(r.published_at, 'unixepoch', '+7 hours') AS date, count(*) AS count FROM reports r
      WHERE r.state='published' AND r.published_at >= ? AND r.published_at < ? GROUP BY date`)
      .bind(firstDay * secondsPerDay - jakartaOffset, (today + 1) * secondsPerDay - jakartaOffset),
  ]);
  const items = results[0].results as PublicReport[];
  const counts: HomeSummary = { found: 0, lost: 0, recent: [] };
  for (const row of results[1].results as Array<{ kind: "found" | "lost"; count: number }>) counts[row.kind] = row.count;
  const dailyCounts = new Map((results[2].results as Array<{ date: string; count: number }>).map(row => [row.date, row.count]));
  for (let day = firstDay; day <= today; day++) {
    const date = new Date(day * secondsPerDay * 1000).toISOString().slice(0, 10);
    counts.recent.push({ date, count: dailyCounts.get(date) ?? 0 });
  }
  return html(homePage(items.slice(0, PAGE_SIZE), counts, filters, page, items.length > PAGE_SIZE));
}

async function submitReport(request: Request, db: D1Database, env: Env) {
  const back = "/laporkan";
  const form = await readForm(request, back);
  const key = nonce(form, back);
  if (await db.prepare("SELECT id FROM reports WHERE request_key=?").bind(key).first()) return redirect("/laporkan/terkirim");
  await rateLimit(request, db, env.GEDUNG_E_APP_KEY, "report", 12, 3600, back);
  const kind = field(form, "kind", "jenis laporan", 8, back);
  const category = field(form, "category", "kategori", 40, back);
  if (!["found", "lost"].includes(kind) || !categories.some(value => value === category)) {
    throw new RequestError(400, "Pilih jenis laporan dan kategori yang tersedia.", back);
  }
  if (form.get("ack") !== "1") throw new RequestError(400, "Konfirmasi penggunaan rincian laporan.", back);
  const title = field(form, "title", "nama barang", 100, back);
  const location = field(form, "location", "lokasi di Gedung E", 120, back);
  const description = field(form, "description", "deskripsi barang", 800, back);
  const reporter = field(form, "reporter_name", "nama pelapor", 100, back);
  const contact = field(form, "reporter_contact", "kontak pelapor", 120, back, false);
  const photo = await preparePhoto(form, "photo", back);
  const id = crypto.randomUUID();
  const photoKey = photo ? `reports/${id}.jpg` : null;
  const report = db.prepare(`
    INSERT INTO reports (id,request_key,kind,title,category,location,description,reporter_name,reporter_contact,photo_key)
    VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(request_key) DO NOTHING
  `).bind(id, key, kind, title, category, location, description, reporter, contact || null, photoKey);

  if (photo) {
    const image = db.prepare(`INSERT INTO photos(key,jpeg) SELECT ?,?
      WHERE EXISTS (SELECT 1 FROM reports WHERE id=? AND photo_key=?)`).bind(photoKey, photo.buffer.slice(photo.byteOffset, photo.byteOffset + photo.byteLength), id, photoKey);
    await writeWithPhoto(db, [report, image], back);
  } else {
    await report.run();
  }
  return redirect("/laporkan/terkirim");
}

async function submitClaim(request: Request, db: D1Database, env: Env, reportId: string) {
  const back = `/klaim/${reportId}`;
  const form = await readForm(request, back);
  const requestKey = nonce(form, back);
  const code = (await keyedHash(env.GEDUNG_E_APP_KEY, `claim:${reportId}:${requestKey}`)).slice(0, 32).toUpperCase();
  const hash = await digest(code);
  const lookup = () => db.prepare(`
    SELECT r.title,c.state,c.pickup FROM claims c JOIN reports r ON r.id=c.report_id
    WHERE c.request_key=? AND c.report_id=? AND c.tracking_hash=?
  `).bind(requestKey, reportId, hash).first<TrackedClaim>();
  const previous = await lookup();
  if (previous) return html(trackingPage(previous, code));
  await rateLimit(request, db, env.GEDUNG_E_APP_KEY, "claim", 20, 3600, back);
  const name = field(form, "claimant_name", "nama pengaju", 100, back);
  const proof = field(form, "proof", "ciri khusus atau bukti kepemilikan", 1000, back);
  await db.prepare(`
    INSERT INTO claims (id,report_id,request_key,tracking_hash,claimant_name,proof)
    SELECT ?,r.id,?,?,?,? FROM reports r
    WHERE r.id=? AND r.kind='found' AND r.state='published'
      AND NOT EXISTS (SELECT 1 FROM claims c WHERE c.report_id=r.id AND c.state IN ('ready','returned'))
    ON CONFLICT(request_key) DO NOTHING
  `).bind(crypto.randomUUID(), requestKey, hash, name, proof, reportId).run();
  const claim = await lookup();
  if (!claim) throw new RequestError(409, "Barang ini sedang tidak menerima pengajuan klaim.", `/barang/${reportId}`);
  return html(trackingPage(claim, code), 201);
}

async function track(request: Request, db: D1Database, env: Env) {
  const back = "/cek-klaim";
  const form = await readForm(request, back);
  await rateLimit(request, db, env.GEDUNG_E_APP_KEY, "track", 50, 600, back);
  const code = field(form, "code", "kode pelacakan", 50, back).toUpperCase().replace(/[\s-]/g, "");
  if (!/^[A-F0-9]{32}$/.test(code)) return html(trackingPage(undefined, undefined, "Periksa kembali kode pelacakan Anda."), 400);
  const claim = await db.prepare(`
    SELECT r.title,c.state,CASE WHEN c.state='ready' THEN c.pickup ELSE NULL END AS pickup
    FROM claims c JOIN reports r ON r.id=c.report_id WHERE c.tracking_hash=?
  `).bind(await digest(code)).first<TrackedClaim>();
  return claim ? html(trackingPage(claim)) : html(trackingPage(undefined, undefined, "Kode pelacakan tidak ditemukan."), 404);
}

async function history(db: D1Database, url: URL) {
  const page = pageNumber(url);
  const rows = await db.prepare(`
    SELECT c.id,r.title,r.category,c.handed_over_at,(c.photo_consent=1 AND c.photo_key IS NOT NULL) AS has_photo
    FROM claims c JOIN reports r ON r.id=c.report_id
    WHERE c.state='returned' ORDER BY c.handed_over_at DESC,c.id LIMIT ? OFFSET ?
  `).bind(PAGE_SIZE + 1, (page - 1) * PAGE_SIZE).all<HistoryEntry>();
  return html(historyPage(rows.results.slice(0, PAGE_SIZE), page, rows.results.length > PAGE_SIZE));
}

async function staffList(db: D1Database, url: URL) {
  const filters: Record<string, string> = {
    pending: "r.state='pending'",
    active: publicCondition,
    claims: `(${publicCondition}) AND EXISTS (SELECT 1 FROM claims c WHERE c.report_id=r.id AND c.state IN ('submitted','ready'))`,
    returned: "EXISTS (SELECT 1 FROM claims c WHERE c.report_id=r.id AND c.state='returned')",
    archived: "r.state='archived'",
  };
  const requested = url.searchParams.get("status") || "";
  const filter = Object.hasOwn(filters, requested) ? requested : "";
  const page = pageNumber(url);
  const results = await db.batch([
    db.prepare(`SELECT ${staffSelect} FROM reports r WHERE ${filters[filter] || "1=1"}
      ORDER BY r.created_at DESC,r.id LIMIT ? OFFSET ?`).bind(PAGE_SIZE + 1, (page - 1) * PAGE_SIZE),
    db.prepare(`SELECT
      (SELECT count(*) FROM reports WHERE state='pending') AS pending,
      (SELECT count(*) FROM reports r WHERE ${publicCondition}) AS active,
      (SELECT count(*) FROM claims WHERE state='returned') AS returned`),
  ]);
  const rows = results[0].results as StaffReport[];
  const counts = results[1].results[0] as { pending: number; active: number; returned: number };
  return html(staffPage(rows.slice(0, PAGE_SIZE), counts, filter, page, rows.length > PAGE_SIZE));
}

const staffMessages: Record<string, string> = {
  published: "Laporan sudah ditayangkan.",
  archived: "Laporan sudah diarsipkan.",
  ready: "Klaim disetujui. Petunjuk pengambilan bisa dilihat dengan kode pelacakan.",
  rejected: "Klaim ditutup.",
  returned: "Serah terima dicatat dan muncul di histori.",
};

async function staffReportAction(request: Request, db: D1Database, report: StaffReport, action: string) {
  const back = `/admin/laporan/${report.id}`;
  if (action === "tayangkan") {
    if (report.state === "published") return redirect(back + "?hasil=published");
    const form = await readForm(request, back);
    if (form.get("scope") !== "1" || (report.kind === "found" && form.get("received") !== "1")) {
      throw new RequestError(400, "Konfirmasi lokasi dan penerimaan barang sebelum menayangkan laporan.", back);
    }
    const result = await db.prepare("UPDATE reports SET state='published',published_at=unixepoch() WHERE id=? AND state='pending'")
      .bind(report.id).run();
    if (changes(result)) return redirect(back + "?hasil=published");
  }
  if (action === "arsipkan") {
    if (report.state === "archived") return redirect(back + "?hasil=archived");
    const result = await db.batch([
      db.prepare(`UPDATE reports SET state='archived' WHERE id=? AND state IN ('pending','published')
        AND NOT EXISTS (SELECT 1 FROM claims WHERE report_id=? AND state IN ('ready','returned'))`).bind(report.id, report.id),
      db.prepare(`UPDATE claims SET state='rejected' WHERE report_id=? AND state='submitted'
        AND EXISTS (SELECT 1 FROM reports WHERE id=? AND state='archived')`).bind(report.id, report.id),
    ]);
    if (changes(result[0])) return redirect(back + "?hasil=archived");
  }
  throw new RequestError(409, "Tindakan tidak tersedia pada status laporan ini. Muat ulang panel.", back);
}

async function staffClaimAction(request: Request, db: D1Database, report: StaffReport, id: string, action: string) {
  const back = `/admin/laporan/${report.id}`;
  const current = await db.prepare("SELECT state FROM claims WHERE id=? AND report_id=?").bind(id, report.id).first<{ state: Claim["state"] }>();
  if (!current) notFound(back);

  if (action === "setujui") {
    if (current.state === "ready") return redirect(back + "?hasil=ready");
    const form = await readForm(request, back);
    const pickup = field(form, "pickup", "petunjuk pengambilan", 240, back);
    if (form.get("verified") !== "1") throw new RequestError(400, "Konfirmasi pemeriksaan kepemilikan.", back);
    const result = await db.prepare(`UPDATE claims SET state='ready',pickup=?
      WHERE id=? AND report_id=? AND state='submitted'
      AND EXISTS (SELECT 1 FROM reports WHERE id=? AND kind='found' AND state='published')
      AND NOT EXISTS (SELECT 1 FROM claims c WHERE c.report_id=? AND c.state IN ('ready','returned'))`)
      .bind(pickup, id, report.id, report.id, report.id).run();
    if (changes(result)) return redirect(back + "?hasil=ready");
  }

  if (action === "tolak") {
    if (current.state === "rejected") return redirect(back + "?hasil=rejected");
    const result = await db.prepare("UPDATE claims SET state='rejected',pickup=NULL WHERE id=? AND report_id=? AND state IN ('submitted','ready')")
      .bind(id, report.id).run();
    if (changes(result)) return redirect(back + "?hasil=rejected");
  }

  if (action === "serahkan") {
    if (current.state === "returned") return redirect(back + "?hasil=returned");
    if (current.state !== "ready") throw new RequestError(409, "Setujui klaim sebelum mencatat serah terima.", back);
    const form = await readForm(request, back);
    if (form.get("confirmed") !== "1") throw new RequestError(400, "Konfirmasi pemeriksaan pemilik dan penyerahan barang.", back);
    const consent = form.get("photo_consent") === "1";
    const file = form.get("handover_photo");
    if (file instanceof File && file.size > 0 && !consent) {
      throw new RequestError(400, "Minta persetujuan penerima untuk foto buram atau catat serah terima tanpa foto.", back);
    }
    const blurred = consent ? await preparePhoto(form, "handover_photo", back, true) : null;
    const photoKey = blurred ? `handover/${crypto.randomUUID()}.jpg` : null;
    const statements = [
      db.prepare(`UPDATE claims SET state='returned',pickup=NULL,photo_key=?,photo_consent=?,handed_over_at=unixepoch()
        WHERE id=? AND report_id=? AND state='ready'
        AND EXISTS (SELECT 1 FROM reports WHERE id=? AND state='published')`)
        .bind(photoKey, photoKey ? 1 : 0, id, report.id, report.id),
      db.prepare(`UPDATE claims SET state='rejected',pickup=NULL WHERE report_id=? AND state='submitted'
        AND EXISTS (SELECT 1 FROM claims WHERE id=? AND report_id=? AND state='returned')`)
        .bind(report.id, id, report.id),
    ];
    if (blurred) {
      statements.push(db.prepare(`INSERT INTO photos(key,jpeg) SELECT ?,?
        WHERE EXISTS (SELECT 1 FROM claims WHERE id=? AND state='returned' AND photo_key=?)`)
        .bind(photoKey, blurred.buffer.slice(blurred.byteOffset, blurred.byteOffset + blurred.byteLength), id, photoKey));
    }
    const results = await writeWithPhoto(db, statements, back);
    if (changes(results[0])) return redirect(back + "?hasil=returned");
  }
  throw new RequestError(409, "Status klaim sudah berubah. Muat ulang panel petugas.", back);
}

async function adminRoute(request: Request, db: D1Database, env: Env, url: URL, segments: string[], get: boolean) {
  const access = await authorizeAdmin(request, db, env, url.pathname, get);
  if (access) return access;

  if (segments.length === 1 && get) return staffList(db, url);
  const [_, area, reportId, action, claimId, claimAction] = segments;
  if (!isId(reportId)) notFound("/admin");
  if (area === "foto" && segments.length === 3 && get) {
    const image = await db.prepare("SELECT p.jpeg FROM reports r JOIN photos p ON p.key=r.photo_key WHERE r.id=?")
      .bind(reportId).first<{ jpeg: number[] }>();
    return photoResponse(image?.jpeg);
  }
  if (area !== "laporan") notFound("/admin");
  const report = await getStaffReport(db, reportId);
  if (!report) notFound("/admin");
  if (segments.length === 3 && get) {
    const claims = await db.prepare(`
      SELECT id,report_id,claimant_name,proof,state,pickup,photo_key,created_at,handed_over_at
      FROM claims WHERE report_id=? ORDER BY
        CASE state WHEN 'ready' THEN 0 WHEN 'submitted' THEN 1 ELSE 2 END, created_at DESC,id
    `).bind(reportId).all<Claim>();
    const message = url.searchParams.get("hasil") || "";
    return html(staffDetail(report, claims.results, Object.hasOwn(staffMessages, message) ? staffMessages[message] : ""));
  }
  if (!get && segments.length === 4 && ["tayangkan", "arsipkan"].includes(action)) {
    return staffReportAction(request, db, report, action);
  }
  if (!get && segments.length === 6 && action === "klaim" && isId(claimId) && ["setujui", "tolak", "serahkan"].includes(claimAction)) {
    return staffClaimAction(request, db, report, claimId, claimAction);
  }
  notFound("/admin");
}

async function route(request: Request, env: Env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const get = request.method === "GET" || request.method === "HEAD";
  if (!get && request.method !== "POST") throw new RequestError(405, "Metode tidak didukung.");
  if (!get) checkOrigin(request, env.GEDUNG_E_ORIGIN);
  if (path === "/alur" && get) return html(journeyPage());
  const db = env.DB;
  if (!db) throw new RequestError(503, "Basis data sedang tidak tersedia. Coba lagi nanti.");
  const segments = path.split("/").filter(Boolean);
  const [area, second, third] = segments;

  if (area === "admin") return adminRoute(request, db, env, url, segments, get);
  if (path === "/" && get) return browse(db, url);
  if (path === "/laporkan") return get ? html(reportPage()) : submitReport(request, db, env);
  if (path === "/laporkan/terkirim" && get) return html(reportSentPage());
  if (path === "/cek-klaim") return get ? html(trackingPage()) : track(request, db, env);
  if (path === "/histori" && get) return history(db, url);
  if (path === "/privasi" && get) return html(privacyPage());

  if (segments.length === 2 && isId(second) && (area === "barang" || area === "klaim")) {
    if (area === "klaim" && !get) return submitClaim(request, db, env, second);
    if (get) {
      const item = await getPublicReport(db, second);
      if (!item) notFound();
      if (area === "barang") return html(reportDetail(item));
      if (item.kind !== "found" || item.ready) throw new RequestError(409, "Barang ini sedang tidak menerima pengajuan klaim.", `/barang/${second}`);
      return html(claimPage(item));
    }
  }
  if (get && area === "foto" && segments.length === 3 && isId(third)) {
    if (second === "barang") {
      const row = await db.prepare(`SELECT p.jpeg FROM reports r JOIN photos p ON p.key=r.photo_key
        WHERE r.id=? AND ${publicCondition}`).bind(third).first<{ jpeg: number[] }>();
      return photoResponse(row?.jpeg);
    }
    if (second === "serah-terima") {
      const row = await db.prepare(`SELECT p.jpeg FROM claims c JOIN photos p ON p.key=c.photo_key
        WHERE c.id=? AND c.state='returned' AND c.photo_consent=1`).bind(third).first<{ jpeg: number[] }>();
      return photoResponse(row?.jpeg);
    }
  }
  notFound();
}

export async function handleGedungE(request: Request, env: Env) {
  try {
    const response = await route(request, env);
    if (request.method === "HEAD") return new Response(null, { status: response.status, headers: response.headers });
    return response;
  } catch (error) {
    if (error instanceof RequestError) {
      const title = error.status === 404 ? "Halaman tidak ditemukan" : "Permintaan tidak dapat diproses";
      return html(errorPage(title, error.message, error.back), error.status);
    }
    console.error(JSON.stringify({ event: "gedung_e_request_failed", method: request.method, category: error instanceof Error ? error.name : "unknown" }));
    return html(errorPage("Layanan sedang bermasalah", "Silakan coba lagi dalam beberapa saat."), 500);
  }
}

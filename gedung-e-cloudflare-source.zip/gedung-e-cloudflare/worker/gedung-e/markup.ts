export function esc(value: unknown) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[char]!);
}

export function icon(name: string) {
  return `<span class="icon icon-${name}" aria-hidden="true"></span>`;
}

export function link(href: string, label: string, variant = "secondary", glyph = "", extra = "") {
  return `<a class="button button-${variant}" href="${esc(href)}" ${extra}>${glyph ? icon(glyph) : ""}<span>${esc(label)}</span></a>`;
}

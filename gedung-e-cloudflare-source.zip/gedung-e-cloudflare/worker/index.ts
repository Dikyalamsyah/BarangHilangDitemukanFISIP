import { handleGedungE } from "./gedung-e/application";

export interface Env {
  DB: D1Database;
  GEDUNG_E_ORIGIN?: string;
  GEDUNG_E_APP_KEY?: string;
  GEDUNG_E_KDF_SALT?: string;
  GEDUNG_E_ADMIN_SETUP?: string;
  GEDUNG_E_ADMIN_RECOVERY?: string;
}

export default { fetch: handleGedungE } satisfies ExportedHandler<Env>;

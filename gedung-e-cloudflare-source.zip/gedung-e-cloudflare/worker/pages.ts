import type { Env } from "./index";
import { handleGedungE } from "./gedung-e/application";

export default {
  fetch(request: Request, env: Env & { ASSETS: Fetcher }) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/assets/")) return env.ASSETS.fetch(request);
    if (env.GEDUNG_E_ORIGIN && url.origin !== env.GEDUNG_E_ORIGIN &&
        (request.method === "GET" || request.method === "HEAD")) {
      const target = new URL(env.GEDUNG_E_ORIGIN);
      target.pathname = url.pathname;
      target.search = url.search;
      return new Response(null, { status: 302, headers: {
        Location: target.href,
        "Cache-Control": "no-store",
        "Referrer-Policy": "no-referrer",
      } });
    }
    return handleGedungE(request, env);
  },
} satisfies ExportedHandler<Env & { ASSETS: Fetcher }>;
